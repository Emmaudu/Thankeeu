const express = require('express');
const router  = express.Router();
const { adminAuth } = require('../middleware/auth');
const {
  getStats, getAllUsers, updateUserRole, deleteUser,
  getAllCards, deleteCard,
  getAllCompanies, deleteCompany, getCompanyTeamMembers,
  getVisitors,
} = require('../controllers/adminController');

router.use(adminAuth);

// Stats
router.get('/stats', getStats);

// Users
router.get('/users',                     getAllUsers);
router.put('/users/:userId/role',        updateUserRole);
router.delete('/users/:userId',          deleteUser);

// Cards
router.get('/cards',                     getAllCards);
router.delete('/cards/:cardId',          deleteCard);

// Companies
router.get('/companies',                 getAllCompanies);
router.delete('/companies/:companyId',   deleteCompany);
router.get('/companies/:companyId/members', getCompanyTeamMembers);

// Visitors (guests who signed cards without an account)
router.get('/visitors',                  getVisitors);

module.exports = router;
