import { format } from 'date-fns';
import { useSEO } from '../hooks/useSEO';
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { adminAPI, adminCompanyAPI, adminSupportAPI, demoAPI, blogAPI } from '../utils/api';
import toast from 'react-hot-toast';
import { formatNGN } from '../utils/currency';
import Icon from '../components/ui/Icon';

// ── Mini helpers ──────────────────────────────────────────────────────────────
const Badge = ({ children, color = 'purple' }) => {
  const cls = {
    purple: 'bg-purple-100 text-purple-700',
    amber:  'bg-amber-100 text-amber-700',
    green:  'bg-green-100 text-green-700',
    blue:   'bg-blue-100 text-blue-700',
    red:    'bg-red-100 text-red-600',
    gray:   'bg-warm-100 text-warm-500',
  }[color] || 'bg-purple-100 text-purple-700';
  return <span className={`inline-block text-xs font-semibold px-2.5 py-0.5 rounded-full capitalize ${cls}`}>{children}</span>;
};

const Stat = ({ icon, label, value, sub, accent }) => (
  <div className="bg-white rounded-2xl border border-purple-100 p-5 hover:shadow-md transition-shadow">
    <div className="flex items-start justify-between mb-3">
      <div className="text-2xl">{icon}</div>
      {sub && <span className="text-xs text-warm-400 font-medium">{sub}</span>}
    </div>
    <p className="text-2xl font-display font-bold text-warm-900">{value}</p>
    <p className="text-xs text-warm-500 mt-1">{label}</p>
  </div>
);

const EmptyState = ({ icon, title, sub }) => (
  <div className="bg-white rounded-2xl border border-purple-100 p-14 text-center">
    <div className="text-5xl mb-4">{icon}</div>
    <p className="font-bold text-warm-900 text-base mb-1">{title}</p>
    {sub && <p className="text-sm text-warm-400">{sub}</p>}
  </div>
);

const PalTicketRow = ({ ticket, onReply }) => {
  const [reply, setReply] = useState(ticket.admin_reply || '');
  const [open, setOpen] = useState(false);
  const STATUS_COLOR = { open:'bg-amber-100 text-amber-700', answered:'bg-green-100 text-green-700', closed:'bg-gray-100 text-gray-600' };

  return (
    <div className="px-5 py-4">
      <div className="flex items-start justify-between gap-3 mb-1">
        <div>
          <p className="font-medium text-warm-900 text-sm">{ticket.group_name} — {ticket.subject}</p>
          <p className="text-xs text-warm-400 mt-0.5">{ticket.message}</p>
        </div>
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 capitalize ${STATUS_COLOR[ticket.status]||STATUS_COLOR.open}`}>{ticket.status}</span>
      </div>
      {ticket.admin_reply && !open && (
        <div className="mt-2 p-2.5 bg-green-50 rounded-lg border-l-2 border-green-400">
          <p className="text-xs text-green-800">{ticket.admin_reply}</p>
        </div>
      )}
      {open ? (
        <div className="mt-2 flex gap-2">
          <input value={reply} onChange={e=>setReply(e.target.value)} placeholder="Type a reply..." className="input flex-1 text-sm"/>
          <button onClick={()=>{ onReply(ticket.id, reply); setOpen(false); }} className="px-3 py-1.5 rounded-lg bg-primary-600 text-white text-xs font-semibold">Send</button>
        </div>
      ) : (
        <button onClick={()=>setOpen(true)} className="mt-2 text-xs text-primary-600 font-semibold">
          {ticket.admin_reply ? 'Edit reply' : 'Reply'}
        </button>
      )}
    </div>
  );
};

const ticketColor = { open:'amber', in_progress:'blue', resolved:'green', closed:'gray' };
const demoColor  = { new:'amber', contacted:'blue', scheduled:'purple', converted:'green', declined:'gray' };

// ── Users Tab (extracted as a proper component to satisfy Rules of Hooks) ─────
const UsersTab = ({ users, setUsers }) => {
  const [giftTarget, setGiftTarget] = React.useState(null);
  const [giftAmount, setGiftAmount] = React.useState('');
  const [giftReason, setGiftReason] = React.useState('');
  const [gifting,    setGifting]    = React.useState(false);

  const openGift  = (u) => { setGiftTarget(u); setGiftAmount(''); setGiftReason(''); };
  const closeGift = ()  => { setGiftTarget(null); };
  const submitGift = async () => {
    const n = parseInt(giftAmount, 10);
    if (!n || n < 1) return toast.error('Enter a valid number of credits');
    setGifting(true);
    try {
      const res = await adminAPI.giftCredits(giftTarget.id, n, giftReason || undefined);
      toast.success(`✅ Gifted ${n} credit${n > 1 ? 's' : ''} to ${giftTarget.full_name}. New balance: ${res.data.new_balance}`);
      setUsers(prev => prev.map(u => u.id === giftTarget.id
        ? { ...u, credits_remaining: res.data.new_balance }
        : u
      ));
      closeGift();
    } catch (e) {
      toast.error(e?.response?.data?.error || 'Failed to gift credits');
    } finally { setGifting(false); }
  };

  return (
    <>
      {/* Gift Credits Modal */}
      {giftTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.45)' }}>
          <div className="bg-white rounded-3xl shadow-2xl border border-purple-100 w-full max-w-sm p-6">
            <h3 className="font-bold text-warm-900 text-lg mb-1">Gift Credits</h3>
            <p className="text-sm text-warm-500 mb-4">
              To <strong>{giftTarget.full_name}</strong> ({giftTarget.email})<br/>
              Current balance: <strong className="text-primary-600">{giftTarget.credits_remaining} credit{giftTarget.credits_remaining !== 1 ? 's' : ''}</strong>
            </p>
            <label className="block text-xs font-bold text-warm-600 mb-1">Number of credits to gift</label>
            <input
              type="number" min="1" max="1000"
              value={giftAmount}
              onChange={e => setGiftAmount(e.target.value)}
              placeholder="e.g. 5"
              className="w-full border border-purple-200 rounded-xl px-4 py-2.5 text-sm mb-3 focus:outline-none focus:ring-2 focus:ring-primary-300"
              style={{ background: '#fff', color: '#1a1a2e' }}
            />
            <label className="block text-xs font-bold text-warm-600 mb-1">Reason (optional)</label>
            <input
              type="text"
              value={giftReason}
              onChange={e => setGiftReason(e.target.value)}
              placeholder="e.g. Promo, refund, goodwill..."
              className="w-full border border-purple-200 rounded-xl px-4 py-2.5 text-sm mb-5 focus:outline-none focus:ring-2 focus:ring-primary-300"
              style={{ background: '#fff', color: '#1a1a2e' }}
            />
            <div className="flex gap-2">
              <button onClick={closeGift} className="flex-1 py-2.5 rounded-xl border border-purple-200 text-sm font-semibold text-warm-600 hover:bg-purple-50">Cancel</button>
              <button onClick={submitGift} disabled={gifting}
                className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white"
                style={{ background: gifting ? '#C4B5FD' : 'linear-gradient(135deg,#7C3AED,#A855F7)' }}>
                {gifting ? 'Gifting…' : `Gift ${giftAmount || '—'} credit${parseInt(giftAmount) === 1 ? '' : 's'}`}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead style={{ background:'#F8F6FF' }}>
              <tr>{['Name','Email','Role','Credits','Birthday','Signed up','Actions'].map(h=>(
                <th key={h} className="text-left px-4 py-3 text-xs font-bold text-warm-500 uppercase tracking-wide">{h}</th>
              ))}</tr>
            </thead>
            <tbody className="divide-y divide-purple-50">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-purple-50/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-xl bg-primary-100 flex items-center justify-center text-xs font-bold text-primary-600">{u.full_name?.[0]||'?'}</div>
                      <span className="text-sm font-semibold text-warm-800">{u.full_name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-warm-500">{u.email}</td>
                  <td className="px-4 py-3"><Badge color={u.role==='admin'?'purple':'gray'}>{u.role}</Badge></td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-bold px-2 py-1 rounded-full ${u.credits_remaining > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-warm-50 text-warm-400'}`}>
                      {u.credits_remaining} credit{u.credits_remaining !== 1 ? 's' : ''}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {u.date_of_birth ? (
                      <span className="text-xs font-semibold text-warm-700">
                        🎂 {format(new Date(u.date_of_birth + 'T00:00:00'), 'MMM d, yyyy')}
                      </span>
                    ) : (
                      <span className="text-xs text-warm-300">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-xs text-warm-400">{u.created_at ? format(new Date(u.created_at),'MMM d, yyyy') : '—'}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1 flex-wrap">
                      <button onClick={() => openGift(u)}
                        className="text-xs bg-emerald-50 text-emerald-700 px-2 py-1 rounded-lg hover:bg-emerald-100 font-semibold">
                        🎁 Gift credits
                      </button>
                      <button onClick={async()=>{
                        if(!confirm(`Change ${u.full_name} to ${u.role==='admin'?'user':'admin'}?`)) return;
                        await adminAPI.updateRole(u.id, u.role==='admin'?'user':'admin');
                        setUsers(p=>p.map(x=>x.id===u.id?{...x,role:x.role==='admin'?'user':'admin'}:x));
                      }} className="text-xs bg-primary-50 text-primary-600 px-2 py-1 rounded-lg hover:bg-primary-100">
                        {u.role==='admin'?'↓ user':'↑ admin'}
                      </button>
                      <button onClick={async()=>{
                        if(!confirm(`Delete ${u.full_name}? This is irreversible.`)) return;
                        await adminAPI.deleteUser(u.id);
                        setUsers(p=>p.filter(x=>x.id!==u.id));
                        toast.success('User deleted');
                      }} className="text-xs text-red-400 hover:bg-red-50 px-2 py-1 rounded-lg">🗑️</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

// ── Broadcast Tab ─────────────────────────────────────────────────────────────
const SEGMENTS = [
  { id: 'all',         label: 'All users',              desc: 'Every registered user on Thankeeu' },
  { id: 'active',      label: 'Active users',           desc: 'Users who have created at least one card' },
  { id: 'inactive_30', label: 'Inactive 30+ days',      desc: 'Signed up 30+ days ago, never created a card' },
  { id: 'inactive_90', label: 'Inactive 90+ days',      desc: 'Signed up 90+ days ago, never created a card' },
  { id: 'visitors',    label: 'Visitors',               desc: 'People who visited a card but haven\'t signed up yet' },
];

// ── Settings Tab ─────────────────────────────────────────────────────────────
const SettingsTab = () => {
  const [currentUrl, setCurrentUrl] = React.useState(null);
  const [loading,    setLoading]    = React.useState(true);
  const [uploading,  setUploading]  = React.useState(false);
  const [removing,   setRemoving]   = React.useState(false);
  const [msg,        setMsg]        = React.useState(null);
  const [dragOver,   setDragOver]   = React.useState(false);
  const fileInputRef = React.useRef(null);

  // Use the same adminAPI that the rest of the admin panel uses —
  // it already has the correct base URL and attaches the auth token automatically.
  React.useEffect(() => {
    adminAPI.getSettings()
      .then(r => setCurrentUrl(r.data?.settings?.movie_bg_music_url || null))
      .catch(e => setMsg({ type: 'err', text: e.response?.data?.error || e.message || 'Failed to load settings' }))
      .finally(() => setLoading(false));
  }, []);

  const handleUpload = async (file) => {
    if (!file) return;
    const validTypes = ['audio/mpeg','audio/mp3','audio/wav','audio/x-wav','audio/m4a',
                        'audio/mp4','audio/aac','audio/ogg','audio/x-m4a','audio/flac'];
    if (!file.type.startsWith('audio/') && !validTypes.includes(file.type)) {
      setMsg({ type: 'err', text: 'Invalid file type. Upload an MP3, WAV, M4A or OGG file.' });
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setMsg({ type: 'err', text: 'File too large. Maximum 20 MB.' });
      return;
    }
    setUploading(true);
    setMsg(null);
    try {
      const form = new FormData();
      form.append('music', file);
      const r = await adminAPI.uploadMusic(form);
      setCurrentUrl(r.data.url);
      setMsg({ type: 'ok', text: `Uploaded: ${file.name}. All new Memory Movies will use this track.` });
    } catch (e) {
      setMsg({ type: 'err', text: e.response?.data?.error || e.message || 'Upload failed' });
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = async () => {
    if (!window.confirm('Remove this track? Movies will use generated ambient music.')) return;
    setRemoving(true);
    setMsg(null);
    try {
      await adminAPI.removeMusic();
      setCurrentUrl(null);
      setMsg({ type: 'ok', text: 'Track removed. Movies will use generated ambient music.' });
    } catch (e) {
      setMsg({ type: 'err', text: e.response?.data?.error || e.message || 'Remove failed' });
    } finally {
      setRemoving(false);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleUpload(file);
  };

  return (
    <div style={{ maxWidth: 640, margin: '0 auto', padding: '32px 16px' }}>
      <h2 style={{ fontWeight: 800, fontSize: 22, color: '#1A1035', marginBottom: 6 }}>Platform Settings</h2>
      <p style={{ color: '#7A6CA8', fontSize: 14, marginBottom: 32 }}>Configure global settings for Thankeeu.</p>

      <div style={{ background: '#fff', border: '2px solid #EDE9FE', borderRadius: 20, overflow: 'hidden' }}>
        {/* Header */}
        <div style={{ padding: '20px 24px', borderBottom: '1.5px solid #EDE9FE', background: '#F9F5FF', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: 'linear-gradient(135deg,#7C3AED,#EC4899)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <span style={{ fontSize: 22 }}>🎵</span>
          </div>
          <div>
            <p style={{ fontWeight: 800, fontSize: 16, color: '#1A1035', margin: 0 }}>Memory Movie Background Music</p>
            <p style={{ fontSize: 13, color: '#7A6CA8', margin: '3px 0 0' }}>Upload an MP3, WAV, M4A or OGG track (max 20 MB). Every Memory Movie generated will use this song.</p>
          </div>
        </div>

        <div style={{ padding: 24 }}>
          {loading ? (
            <div style={{ textAlign: 'center', padding: 32, color: '#A898CC', fontSize: 14 }}>Loading settings…</div>
          ) : (
            <>
              {/* Current track status */}
              <div style={{
                background: currentUrl ? '#F0FDF4' : '#F5F0FF',
                border: `2px solid ${currentUrl ? '#86EFAC' : '#DDD6FE'}`,
                borderRadius: 14, padding: '14px 18px', marginBottom: 20,
                display: 'flex', alignItems: 'flex-start', gap: 12,
              }}>
                <span style={{ fontSize: 22, flexShrink: 0 }}>{currentUrl ? '🎶' : '🔕'}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontWeight: 700, fontSize: 14, color: currentUrl ? '#166534' : '#4B3F72', margin: '0 0 4px' }}>
                    {currentUrl ? 'Custom track active' : 'Using generated ambient music'}
                  </p>
                  {currentUrl
                    ? <p style={{ fontSize: 11, color: '#5A7B6A', wordBreak: 'break-all', margin: 0, lineHeight: 1.5 }}>{currentUrl}</p>
                    : <p style={{ fontSize: 12, color: '#7A6CA8', margin: 0 }}>No custom track uploaded. Movies use layered ambient tones generated by ffmpeg.</p>
                  }
                </div>
                {currentUrl && (
                  <button onClick={handleRemove} disabled={removing} style={{
                    flexShrink: 0, background: 'none', border: '1.5px solid #FCA5A5',
                    borderRadius: 8, color: '#DC2626', fontSize: 12, fontWeight: 700,
                    padding: '5px 12px', cursor: removing ? 'not-allowed' : 'pointer', opacity: removing ? 0.6 : 1,
                  }}>
                    {removing ? 'Removing…' : 'Remove'}
                  </button>
                )}
              </div>

              {/* Drop zone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                onClick={() => !uploading && fileInputRef.current?.click()}
                style={{
                  border: `2px dashed ${dragOver ? '#7C3AED' : '#C4B5FD'}`,
                  borderRadius: 16, padding: '36px 24px', textAlign: 'center',
                  cursor: uploading ? 'not-allowed' : 'pointer',
                  background: dragOver ? '#F5F0FF' : '#FDFCFF',
                  transition: 'all 0.15s', opacity: uploading ? 0.7 : 1,
                }}>
                <div style={{ fontSize: 36, marginBottom: 10 }}>{uploading ? '⏳' : '🎵'}</div>
                <p style={{ fontWeight: 700, fontSize: 15, color: '#4B3F72', margin: '0 0 6px' }}>
                  {uploading ? 'Uploading to Cloudinary…' : 'Drop your music file here'}
                </p>
                <p style={{ fontSize: 13, color: '#A898CC', margin: 0 }}>
                  {uploading ? 'Please wait…' : 'or click to browse — MP3, WAV, M4A, OGG up to 20 MB'}
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*,.mp3,.wav,.m4a,.ogg,.aac"
                  style={{ display: 'none' }}
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload(f); e.target.value = ''; }}
                />
              </div>

              {/* Feedback */}
              {msg && (
                <div style={{
                  marginTop: 16, padding: '12px 16px', borderRadius: 12,
                  background: msg.type === 'ok' ? '#F0FDF4' : '#FEF2F2',
                  border: `1.5px solid ${msg.type === 'ok' ? '#86EFAC' : '#FCA5A5'}`,
                  color: msg.type === 'ok' ? '#166534' : '#DC2626',
                  fontSize: 13, fontWeight: 600,
                }}>
                  {msg.type === 'ok' ? '✓ ' : '✕ '}{msg.text}
                </div>
              )}

              <p style={{ marginTop: 16, fontSize: 12, color: '#C4B5FD', lineHeight: 1.6 }}>
                The file is stored on Cloudinary. Every Memory Movie generated fetches this URL from the database at render time. Uploading a new file replaces the previous one.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};


const CoverDesignTab = () => {
  const [occasions,      setOccasions]      = React.useState([]);
  const [occasion,       setOccasion]       = React.useState('');
  const [designs,        setDesigns]        = React.useState([]);
  const [loadingOccasions, setLoadingOccasions] = React.useState(true);
  const [loadingDesigns, setLoadingDesigns] = React.useState(false);
  const [uploading,      setUploading]      = React.useState(false);
  const [uploadProgress, setUploadProgress] = React.useState(null); // { done, total } while uploading
  const [dragOver,       setDragOver]       = React.useState(false);
  const [deletingId,     setDeletingId]     = React.useState(null);
  const [msg,            setMsg]            = React.useState(null);
  const [pendingFiles,   setPendingFiles]   = React.useState([]); // previewed before confirming upload
  const fileInputRef = React.useRef(null);

  // Load occasion list once
  React.useEffect(() => {
    adminAPI.getCoverDesignOccasions()
      .then(r => {
        const list = r.data?.occasions || [];
        setOccasions(list);
        if (list.length) setOccasion(list[0].id);
      })
      .catch(e => setMsg({ type: 'err', text: e.response?.data?.error || 'Could not load occasions' }))
      .finally(() => setLoadingOccasions(false));
  }, []);

  const fetchDesigns = React.useCallback((occ) => {
    if (!occ) return;
    setLoadingDesigns(true);
    adminAPI.getCoverDesigns(occ)
      .then(r => setDesigns(r.data?.designs || []))
      .catch(e => setMsg({ type: 'err', text: e.response?.data?.error || 'Could not load designs' }))
      .finally(() => setLoadingDesigns(false));
  }, []);

  React.useEffect(() => { fetchDesigns(occasion); }, [occasion, fetchDesigns]);

  const revokeAll = (files) => files.forEach(f => { try { URL.revokeObjectURL(f.preview); } catch {} });

  const handleFilesSelected = (fileList) => {
    setMsg(null);
    const files = Array.from(fileList || []);
    const accepted = [];
    for (const f of files) {
      if (!f.type.startsWith('image/')) {
        setMsg({ type: 'err', text: `${f.name} is not an image — skipped.` });
        continue;
      }
      if (f.size > 9 * 1024 * 1024) {
        setMsg({ type: 'err', text: `${f.name} is over 9MB — skipped.` });
        continue;
      }
      accepted.push({ file: f, preview: URL.createObjectURL(f) });
    }
    if (accepted.length) setPendingFiles(prev => [...prev, ...accepted]);
  };

  const removePending = (idx) => {
    setPendingFiles(prev => {
      const copy = [...prev];
      const [removed] = copy.splice(idx, 1);
      if (removed) URL.revokeObjectURL(removed.preview);
      return copy;
    });
  };

  const clearPending = () => { revokeAll(pendingFiles); setPendingFiles([]); };

  const confirmUpload = async () => {
    if (!occasion) return setMsg({ type: 'err', text: 'Choose an occasion first' });
    if (!pendingFiles.length) return setMsg({ type: 'err', text: 'Add at least one image first' });
    setUploading(true);
    setUploadProgress({ done: 0, total: pendingFiles.length });
    setMsg(null);
    try {
      const fd = new FormData();
      fd.append('occasion', occasion);
      // Order matters: file[0] here becomes the newest/top-most design, so
      // the order the admin arranged them in (selection/drop order) is
      // exactly the order they'll queue at the top of the live picker.
      pendingFiles.forEach(p => fd.append('designs', p.file));
      const r = await adminAPI.uploadCoverDesigns(fd);
      setMsg({ type: 'ok', text: r.data?.message || `${pendingFiles.length} design(s) uploaded.` });
      clearPending();
      fetchDesigns(occasion);
    } catch (e) {
      setMsg({ type: 'err', text: e.response?.data?.error || e.message || 'Upload failed' });
    } finally {
      setUploading(false);
      setUploadProgress(null);
    }
  };

  const handleDelete = async (design) => {
    if (!window.confirm(`Remove "${design.name || 'this design'}"? It will disappear from the live design picker immediately.`)) return;
    setDeletingId(design.id);
    try {
      await adminAPI.deleteCoverDesign(design.id);
      setDesigns(prev => prev.filter(d => d.id !== design.id));
      setMsg({ type: 'ok', text: 'Design deleted.' });
    } catch (e) {
      setMsg({ type: 'err', text: e.response?.data?.error || 'Delete failed' });
    } finally {
      setDeletingId(null);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleFilesSelected(e.dataTransfer.files);
  };

  const occasionLabel = occasions.find(o => o.id === occasion)?.label || occasion;

  return (
    <div style={{ maxWidth: 980, margin: '0 auto', padding: '32px 16px' }}>
      <h2 style={{ fontWeight: 800, fontSize: 22, color: '#1A1035', marginBottom: 6 }}>Cover Design</h2>
      <p style={{ color: '#7A6CA8', fontSize: 14, marginBottom: 28, lineHeight: 1.6 }}>
        Bulk-upload cover designs per occasion. New uploads appear <strong>first</strong> in the design picker
        wherever covers are shown — older uploads and the built-in designs simply queue behind them, none are lost.
      </p>

      {/* Occasion selector */}
      <div style={{ background: '#fff', border: '2px solid #EDE9FE', borderRadius: 20, padding: 24, marginBottom: 20 }}>
        <label style={{ display: 'block', fontSize: 13, fontWeight: 800, color: '#1A1035', marginBottom: 8 }}>Occasion</label>
        {loadingOccasions ? (
          <div style={{ color: '#A898CC', fontSize: 13 }}>Loading occasions…</div>
        ) : (
          <select
            value={occasion}
            onChange={e => { setOccasion(e.target.value); clearPending(); setMsg(null); }}
            style={{
              width: '100%', maxWidth: 360, padding: '10px 14px', borderRadius: 12,
              border: '1.5px solid #DDD6FE', fontSize: 14, fontWeight: 700, color: '#1A1035',
              background: '#FDFCFF', cursor: 'pointer',
            }}>
            {occasions.map(o => <option key={o.id} value={o.id}>{o.label}</option>)}
          </select>
        )}
        <p style={{ fontSize: 12, color: '#A898CC', marginTop: 8 }}>
          Uploads are scoped to this occasion — designs uploaded here only ever appear when someone is
          creating a card for "{occasionLabel}".
        </p>
      </div>

      {/* Bulk upload zone */}
      <div style={{ background: '#fff', border: '2px solid #EDE9FE', borderRadius: 20, padding: 24, marginBottom: 20 }}>
        <p style={{ fontWeight: 800, fontSize: 15, color: '#1A1035', margin: '0 0 4px' }}>Bulk upload designs</p>
        <p style={{ fontSize: 13, color: '#7A6CA8', margin: '0 0 16px' }}>
          JPG, PNG or WEBP, up to 9MB each. Select or drop multiple files at once — they'll queue in the order
          you add them, with the first file becoming the newest (top) design.
        </p>

        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          onClick={() => !uploading && fileInputRef.current?.click()}
          style={{
            border: `2px dashed ${dragOver ? '#7C3AED' : '#C4B5FD'}`,
            borderRadius: 16, padding: '32px 24px', textAlign: 'center',
            cursor: uploading ? 'not-allowed' : 'pointer',
            background: dragOver ? '#F5F0FF' : '#FDFCFF',
            transition: 'all 0.15s', opacity: uploading ? 0.7 : 1,
          }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🎨</div>
          <p style={{ fontWeight: 700, fontSize: 14, color: '#4B3F72', margin: '0 0 4px' }}>
            Drop cover images here, or click to browse
          </p>
          <p style={{ fontSize: 12, color: '#A898CC', margin: 0 }}>You can select multiple files at once</p>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            multiple
            style={{ display: 'none' }}
            onChange={(e) => { handleFilesSelected(e.target.files); e.target.value = ''; }}
          />
        </div>

        {/* Pending preview grid — nothing is uploaded until Confirm is pressed */}
        {pendingFiles.length > 0 && (
          <div style={{ marginTop: 18 }}>
            <p style={{ fontSize: 12, fontWeight: 800, color: '#1A1035', marginBottom: 10 }}>
              {pendingFiles.length} design{pendingFiles.length === 1 ? '' : 's'} ready to upload — order shown is upload order (first = newest)
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(110px, 1fr))', gap: 10 }}>
              {pendingFiles.map((p, idx) => (
                <div key={idx} style={{ position: 'relative', borderRadius: 12, overflow: 'hidden', border: '2px solid #EDE9FE', aspectRatio: '3/4', background: '#F5F0FF' }}>
                  {idx === 0 && (
                    <span style={{ position: 'absolute', top: 5, left: 5, zIndex: 2, background: '#7C3AED', color: '#fff', fontSize: 9, fontWeight: 800, padding: '2px 6px', borderRadius: 999 }}>TOP</span>
                  )}
                  <img src={p.preview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <button type="button" onClick={() => removePending(idx)} disabled={uploading}
                    style={{ position: 'absolute', top: 5, right: 5, width: 22, height: 22, borderRadius: '50%', border: 'none', background: 'rgba(0,0,0,0.65)', color: '#fff', fontSize: 13, cursor: uploading ? 'not-allowed' : 'pointer', lineHeight: '22px' }}>×</button>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
              <button type="button" onClick={confirmUpload} disabled={uploading}
                style={{ flex: 1, background: 'linear-gradient(135deg,#7C3AED,#EC4899)', color: '#fff', border: 'none', borderRadius: 12, padding: '11px 18px', fontWeight: 800, fontSize: 14, cursor: uploading ? 'not-allowed' : 'pointer', opacity: uploading ? 0.7 : 1 }}>
                {uploading ? `Uploading ${uploadProgress ? `${uploadProgress.done}/${uploadProgress.total}` : '…'}` : `Upload ${pendingFiles.length} design${pendingFiles.length === 1 ? '' : 's'} to "${occasionLabel}"`}
              </button>
              <button type="button" onClick={clearPending} disabled={uploading}
                style={{ background: '#F5F0FF', color: '#7A6CA8', border: '1.5px solid #EDE9FE', borderRadius: 12, padding: '11px 18px', fontWeight: 700, fontSize: 13, cursor: uploading ? 'not-allowed' : 'pointer' }}>
                Clear
              </button>
            </div>
          </div>
        )}

        {msg && (
          <div style={{
            marginTop: 16, padding: '12px 16px', borderRadius: 12,
            background: msg.type === 'ok' ? '#F0FDF4' : '#FEF2F2',
            border: `1.5px solid ${msg.type === 'ok' ? '#86EFAC' : '#FCA5A5'}`,
            color: msg.type === 'ok' ? '#166534' : '#DC2626',
            fontSize: 13, fontWeight: 600,
          }}>
            {msg.type === 'ok' ? '✓ ' : '✕ '}{msg.text}
          </div>
        )}
      </div>

      {/* Existing designs for this occasion — the actual live queue */}
      <div style={{ background: '#fff', border: '2px solid #EDE9FE', borderRadius: 20, padding: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <p style={{ fontWeight: 800, fontSize: 15, color: '#1A1035', margin: 0 }}>
            Live queue for "{occasionLabel}" {designs.length > 0 && <span style={{ color: '#A898CC', fontWeight: 600 }}>({designs.length})</span>}
          </p>
          <button type="button" onClick={() => fetchDesigns(occasion)} disabled={loadingDesigns}
            style={{ background: 'none', border: '1px solid #DDD6FE', borderRadius: 8, color: '#7C3AED', fontSize: 12, fontWeight: 700, padding: '5px 12px', cursor: 'pointer' }}>
            {loadingDesigns ? 'Refreshing…' : 'Refresh'}
          </button>
        </div>

        {loadingDesigns ? (
          <div style={{ textAlign: 'center', padding: 32, color: '#A898CC', fontSize: 14 }}>Loading…</div>
        ) : designs.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 32, color: '#A898CC', fontSize: 13 }}>
            No admin-uploaded designs for this occasion yet. The design picker is showing only the built-in
            designs — upload some above and they'll appear here and on the live site immediately.
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: 12 }}>
            {designs.map((d, idx) => (
              <div key={d.id} style={{ position: 'relative', borderRadius: 14, overflow: 'hidden', border: '2px solid #EDE9FE', background: '#F5F0FF' }}>
                {idx === 0 && (
                  <span style={{ position: 'absolute', top: 6, left: 6, zIndex: 2, background: '#7C3AED', color: '#fff', fontSize: 9, fontWeight: 800, padding: '2px 7px', borderRadius: 999 }}>NEWEST · TOP OF QUEUE</span>
                )}
                <div style={{ aspectRatio: '3/4', overflow: 'hidden' }}>
                  <img src={d.image_url} alt={d.name || ''} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
                <div style={{ padding: '8px 10px' }}>
                  <p style={{ fontSize: 11, fontWeight: 700, color: '#1A1035', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{d.name || 'Untitled'}</p>
                  <p style={{ fontSize: 9, color: '#A898CC', margin: '2px 0 0' }}>{new Date(d.created_at).toLocaleDateString()}</p>
                </div>
                <button type="button" onClick={() => handleDelete(d)} disabled={deletingId === d.id}
                  style={{ position: 'absolute', top: 6, right: 6, width: 24, height: 24, borderRadius: '50%', border: 'none', background: 'rgba(220,38,38,0.9)', color: '#fff', fontSize: 13, cursor: deletingId === d.id ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {deletingId === d.id ? '…' : '×'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};


const BroadcastTab = () => {
  const [subject,    setSubject]    = React.useState('');
  const [body,       setBody]       = React.useState('');
  const [segment,    setSegment]    = React.useState('all');
  const [testEmail,  setTestEmail]  = React.useState('');
  const [preview,    setPreview]    = React.useState(null);
  const [previewing, setPreviewing] = React.useState(false);
  const [sending,    setSending]    = React.useState(false);
  const [result,     setResult]     = React.useState(null);

  const fetchPreview = async (seg = segment) => {
    setPreviewing(true);
    try {
      const r = await adminAPI.broadcastPreview(seg);
      setPreview(r.data.count);
    } catch { setPreview(null); }
    finally { setPreviewing(false); }
  };

  const handleSegmentChange = (seg) => {
    setSegment(seg);
    setPreview(null);
    fetchPreview(seg);
  };

  React.useEffect(() => { fetchPreview('all'); }, []);

  const sendTest = async () => {
    if (!testEmail.trim()) return toast.error('Enter a test email address');
    if (!subject.trim())   return toast.error('Subject is required');
    if (!body.trim())      return toast.error('Email body is required');
    setSending(true); setResult(null);
    try {
      const r = await adminAPI.broadcast({ subject, body, test_email: testEmail.trim() });
      toast.success(r.data.message);
      setResult({ type: 'test', ...r.data });
    } catch (e) { toast.error(e?.response?.data?.error || 'Failed to send test'); }
    finally { setSending(false); }
  };

  const sendBroadcast = async () => {
    if (!subject.trim()) return toast.error('Subject is required');
    if (!body.trim())    return toast.error('Email body is required');
    const seg = SEGMENTS.find(s => s.id === segment);
    const confirmed = window.confirm(
      `Send this email to ${preview !== null ? preview : '?'} ${seg?.label.toLowerCase()}?\n\nSubject: ${subject}\n\nReplies will go to support@thankeeu.com.\n\nThis cannot be undone.`
    );
    if (!confirmed) return;
    setSending(true); setResult(null);
    try {
      const r = await adminAPI.broadcast({ subject, body, segment });
      toast.success(r.data.message);
      setResult({ type: 'broadcast', ...r.data });
    } catch (e) { toast.error(e?.response?.data?.error || 'Broadcast failed'); }
    finally { setSending(false); }
  };

  const segInfo = SEGMENTS.find(s => s.id === segment);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 style={{ fontSize:18, fontWeight:800, color:'#1a1a2e', margin:'0 0 4px' }}>📣 Email Broadcast</h2>
        <p style={{ fontSize:13, color:'#9CA3AF', margin:0 }}>Send a message to your users. Replies go to <strong>support@thankeeu.com</strong>.</p>
      </div>

      {/* Result banner */}
      {result && (
        <div style={{ background: result.type === 'test' ? '#EFF6FF' : '#F0FDF4', border: `1px solid ${result.type === 'test' ? '#BFDBFE' : '#BBF7D0'}`, borderRadius:12, padding:'14px 18px' }}>
          <p style={{ margin:0, fontWeight:700, fontSize:14, color: result.type === 'test' ? '#1D4ED8' : '#15803D' }}>
            {result.type === 'test' ? '🧪 Test sent!' : '✅ Broadcast complete!'}
          </p>
          <p style={{ margin:'4px 0 0', fontSize:13, color:'#374151' }}>{result.message}</p>
          {result.failed > 0 && <p style={{ margin:'4px 0 0', fontSize:12, color:'#DC2626' }}>{result.failed} emails failed to send.</p>}
        </div>
      )}

      {/* Segment picker */}
      <div style={{ background:'white', border:'1px solid #EDE9FF', borderRadius:16, padding:20 }}>
        <p style={{ margin:'0 0 12px', fontWeight:700, fontSize:13, color:'#374151' }}>1. Choose audience</p>
        <div className="grid grid-cols-2 gap-3">
          {SEGMENTS.map(s => (
            <button key={s.id} onClick={() => handleSegmentChange(s.id)}
              style={{
                textAlign:'left', padding:'12px 14px', borderRadius:12, cursor:'pointer', border: `2px solid ${segment === s.id ? '#7C3AED' : '#EDE9FF'}`,
                background: segment === s.id ? '#F5F3FF' : 'white', transition:'all .12s',
              }}>
              <p style={{ margin:'0 0 2px', fontWeight:700, fontSize:13, color: segment === s.id ? '#7C3AED' : '#1a1a2e' }}>{s.label}</p>
              <p style={{ margin:0, fontSize:11, color:'#9CA3AF' }}>{s.desc}</p>
            </button>
          ))}
        </div>
        <div style={{ marginTop:12, padding:'10px 14px', background:'#F8F6FF', borderRadius:10, display:'flex', alignItems:'center', gap:8 }}>
          {previewing
            ? <span style={{ fontSize:13, color:'#9CA3AF' }}>Counting recipients…</span>
            : preview !== null
              ? <><span style={{ fontSize:22, fontWeight:800, color:'#7C3AED' }}>{preview.toLocaleString()}</span><span style={{ fontSize:13, color:'#6B7280' }}> {segInfo?.label.toLowerCase()} will receive this email</span></>
              : <button onClick={() => fetchPreview(segment)} style={{ fontSize:13, color:'#7C3AED', fontWeight:600, background:'none', border:'none', cursor:'pointer' }}>Check recipient count →</button>
          }
        </div>
      </div>

      {/* Compose */}
      <div style={{ background:'white', border:'1px solid #EDE9FF', borderRadius:16, padding:20 }}>
        <p style={{ margin:'0 0 14px', fontWeight:700, fontSize:13, color:'#374151' }}>2. Compose email</p>
        <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#6B7280', marginBottom:6 }}>Subject line *</label>
        <input
          value={subject} onChange={e => setSubject(e.target.value)}
          placeholder="e.g. Exciting news from Thankeeu 🎉"
          style={{ width:'100%', border:'1px solid #DDD6FE', borderRadius:10, padding:'10px 14px', fontSize:14, color:'#1a1a2e', outline:'none', boxSizing:'border-box', marginBottom:16 }}
        />
        <label style={{ display:'block', fontSize:12, fontWeight:600, color:'#6B7280', marginBottom:6 }}>
          Message body * <span style={{ fontWeight:400, color:'#9CA3AF' }}>(plain text — use double line breaks for paragraphs)</span>
        </label>
        <textarea
          value={body} onChange={e => setBody(e.target.value)}
          rows={10}
          placeholder={"We've been working hard to make Thankeeu better for you...\n\nHere's what's new this month:\n\n• Feature one\n• Feature two\n\nThank you for being part of the Thankeeu community.\n\nWarm regards,\nEmmanuel\nCEO, Thankeeu"}
          style={{ width:'100%', border:'1px solid #DDD6FE', borderRadius:10, padding:'10px 14px', fontSize:14, color:'#1a1a2e', outline:'none', boxSizing:'border-box', resize:'vertical', fontFamily:'inherit', lineHeight:1.7 }}
        />
        <p style={{ margin:'8px 0 0', fontSize:11, color:'#9CA3AF' }}>
          Sent as a plain personal email from Emmanuel — no banners, no unsubscribe footer. Designed to land in Primary inbox. Replies go to <strong>support@thankeeu.com</strong>.
        </p>
      </div>

      {/* Test + Send */}
      <div style={{ background:'white', border:'1px solid #EDE9FF', borderRadius:16, padding:20, display:'flex', flexDirection:'column', gap:14 }}>
        <p style={{ margin:0, fontWeight:700, fontSize:13, color:'#374151' }}>3. Send</p>

        {/* Test send */}
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          <input
            value={testEmail} onChange={e => setTestEmail(e.target.value)}
            placeholder="your@email.com — send a test first"
            style={{ flex:1, border:'1px solid #DDD6FE', borderRadius:10, padding:'9px 14px', fontSize:13, color:'#1a1a2e', outline:'none' }}
          />
          <button onClick={sendTest} disabled={sending}
            style={{ padding:'9px 18px', borderRadius:10, border:'1px solid #DDD6FE', background:'white', color:'#7C3AED', fontSize:13, fontWeight:700, cursor: sending ? 'not-allowed' : 'pointer', whiteSpace:'nowrap', opacity: sending ? 0.6 : 1 }}>
            🧪 Send test
          </button>
        </div>

        {/* Real broadcast */}
        <button onClick={sendBroadcast} disabled={sending || preview === null || preview === 0}
          style={{
            padding:'12px 24px', borderRadius:12, border:'none',
            background: sending || preview === null || preview === 0 ? '#C4B5FD' : 'linear-gradient(135deg,#7C3AED,#EC4899)',
            color:'white', fontSize:15, fontWeight:800, cursor: sending || preview === null || preview === 0 ? 'not-allowed' : 'pointer',
            display:'flex', alignItems:'center', justifyContent:'center', gap:8,
          }}>
          {sending
            ? '⏳ Sending…'
            : preview === null
            ? '📣 Load recipient count first'
            : `📣 Send to ${preview.toLocaleString()} ${segInfo?.label.toLowerCase()}`
          }
        </button>
        {preview === 0 && <p style={{ margin:0, fontSize:12, color:'#DC2626' }}>No users in this segment — pick a different audience.</p>}
        {preview === null && !previewing && <p style={{ margin:0, fontSize:12, color:'#9CA3AF' }}>Select an audience above to see recipient count.</p>}
      </div>
    </div>
  );
};

// ── Admin component ───────────────────────────────────────────────────────────
const DiscountCodesTab = ({ codes, loading, onCreate, onToggle, onDelete, redemptions, onLoadRedemptions }) => {
  const [showForm, setShowForm] = React.useState(false);
  const [form, setForm] = React.useState({
    code: '', percent_off: '', max_discount_ngn: '', max_uses: '', expires_at: '',
    banner_enabled: false, banner_text: '',
  });
  const [saving, setSaving] = React.useState(false);

  const resetForm = () => setForm({ code: '', percent_off: '', max_discount_ngn: '', max_uses: '', expires_at: '', banner_enabled: false, banner_text: '' });

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    const ok = await onCreate({
      code: form.code,
      percent_off: Number(form.percent_off),
      max_discount_ngn: form.max_discount_ngn || undefined,
      max_uses: form.max_uses || undefined,
      expires_at: form.expires_at || undefined,
      banner_enabled: form.banner_enabled,
      banner_text: form.banner_text || undefined,
    });
    setSaving(false);
    if (ok) { resetForm(); setShowForm(false); }
  };

  const activeBannerCode = codes.find(c => c.banner_enabled);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-purple-100 p-4">
          <p className="text-xs text-warm-400 mb-1">Total Codes</p>
          <p className="text-2xl font-bold text-warm-900">{codes.length}</p>
        </div>
        <div className="bg-white rounded-2xl border border-purple-100 p-4">
          <p className="text-xs text-warm-400 mb-1">Active</p>
          <p className="text-2xl font-bold text-green-600">{codes.filter(c => c.is_active).length}</p>
        </div>
        <div className="bg-white rounded-2xl border border-purple-100 p-4">
          <p className="text-xs text-warm-400 mb-1">Total Redemptions</p>
          <p className="text-2xl font-bold text-warm-900">{codes.reduce((s, c) => s + (c.used_count || 0), 0)}</p>
        </div>
        <div className="bg-white rounded-2xl border border-purple-100 p-4">
          <p className="text-xs text-warm-400 mb-1">Banner Live</p>
          <p className="text-sm font-bold text-warm-900">{activeBannerCode ? activeBannerCode.code : 'None'}</p>
        </div>
      </div>

      <button onClick={() => setShowForm(s => !s)}
        className="px-4 py-2.5 rounded-xl bg-primary-500 text-white text-sm font-bold hover:bg-primary-600">
        {showForm ? 'Cancel' : '+ New Discount Code'}
      </button>

      {showForm && (
        <form onSubmit={handleCreate} className="bg-white rounded-2xl border border-purple-100 p-5 space-y-4 max-w-xl">
          <div>
            <label className="block text-xs font-semibold text-warm-500 mb-1">Code</label>
            <input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
              placeholder="LAUNCH20" required className="input w-full" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-warm-500 mb-1">Percent off</label>
              <input type="number" min="1" max="100" value={form.percent_off}
                onChange={e => setForm(f => ({ ...f, percent_off: e.target.value }))}
                placeholder="20" required className="input w-full" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-warm-500 mb-1">Max discount (₦, optional)</label>
              <input type="number" min="1" value={form.max_discount_ngn}
                onChange={e => setForm(f => ({ ...f, max_discount_ngn: e.target.value }))}
                placeholder="No cap" className="input w-full" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-warm-500 mb-1">Max uses (optional)</label>
              <input type="number" min="1" value={form.max_uses}
                onChange={e => setForm(f => ({ ...f, max_uses: e.target.value }))}
                placeholder="Unlimited" className="input w-full" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-warm-500 mb-1">Expires (optional)</label>
              <input type="date" value={form.expires_at}
                onChange={e => setForm(f => ({ ...f, expires_at: e.target.value }))}
                className="input w-full" />
            </div>
          </div>
          <div className="border-t border-purple-100 pt-4">
            <label className="flex items-center gap-2 text-sm font-semibold text-warm-700 mb-2">
              <input type="checkbox" checked={form.banner_enabled}
                onChange={e => setForm(f => ({ ...f, banner_enabled: e.target.checked }))} />
              Show as a banner above the navbar site-wide
            </label>
            {form.banner_enabled && (
              <>
                <textarea value={form.banner_text} onChange={e => setForm(f => ({ ...f, banner_text: e.target.value }))}
                  placeholder="e.g. 20% off all cards this week — use LAUNCH20 at checkout"
                  maxLength={140} rows={2} required className="input w-full" />
                <p className="text-xs text-warm-400 mt-1">{form.banner_text.length}/140 · Enabling this will turn off any other active banner.</p>
              </>
            )}
          </div>
          <button type="submit" disabled={saving} className="px-5 py-2.5 rounded-xl bg-primary-500 text-white text-sm font-bold disabled:opacity-60">
            {saving ? 'Creating…' : 'Create Code'}
          </button>
        </form>
      )}

      {loading ? (
        <p className="text-warm-400 text-sm">Loading…</p>
      ) : codes.length === 0 ? (
        <EmptyState icon="Tag" title="No discount codes yet" sub="Create one above to get started" />
      ) : (
        <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-purple-50/50 text-left text-xs text-warm-500">
              <tr>
                <th className="px-4 py-3">Code</th>
                <th className="px-4 py-3">Off</th>
                <th className="px-4 py-3">Cap</th>
                <th className="px-4 py-3">Uses</th>
                <th className="px-4 py-3">Expires</th>
                <th className="px-4 py-3">Banner</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {codes.map(c => {
                const expired = c.expires_at && new Date(c.expires_at) < new Date();
                const exhausted = c.max_uses !== null && c.used_count >= c.max_uses;
                return (
                  <React.Fragment key={c.id}>
                    <tr className="border-t border-purple-50">
                      <td className="px-4 py-3 font-bold text-warm-900">{c.code}</td>
                      <td className="px-4 py-3">{c.percent_off}%</td>
                      <td className="px-4 py-3 text-warm-500">{c.max_discount_ngn ? `₦${c.max_discount_ngn.toLocaleString()}` : '—'}</td>
                      <td className="px-4 py-3 text-warm-500">{c.used_count}{c.max_uses ? ` / ${c.max_uses}` : ''}</td>
                      <td className="px-4 py-3 text-warm-500">{c.expires_at ? format(new Date(c.expires_at), 'MMM d, yyyy') : '—'}</td>
                      <td className="px-4 py-3">{c.banner_enabled ? <Badge color="purple">Live</Badge> : '—'}</td>
                      <td className="px-4 py-3">
                        {!c.is_active ? <Badge color="red">Inactive</Badge>
                          : expired ? <Badge color="orange">Expired</Badge>
                          : exhausted ? <Badge color="orange">Exhausted</Badge>
                          : <Badge color="green">Active</Badge>}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1.5">
                          <button onClick={() => onToggle(c.id, { is_active: !c.is_active })}
                            className="text-xs px-2.5 py-1 rounded-lg border border-purple-200 text-warm-600 hover:bg-purple-50">
                            {c.is_active ? 'Deactivate' : 'Activate'}
                          </button>
                          <button onClick={() => onToggle(c.id, { banner_enabled: !c.banner_enabled })}
                            disabled={!c.banner_text}
                            title={!c.banner_text ? 'No banner text set on this code' : ''}
                            className="text-xs px-2.5 py-1 rounded-lg border border-purple-200 text-warm-600 hover:bg-purple-50 disabled:opacity-40">
                            {c.banner_enabled ? 'Hide banner' : 'Show banner'}
                          </button>
                          <button onClick={() => onLoadRedemptions(c.id)}
                            className="text-xs px-2.5 py-1 rounded-lg border border-purple-200 text-warm-600 hover:bg-purple-50">
                            {redemptions[c.id] ? 'Hide uses' : 'See who used it'}
                          </button>
                          <button onClick={() => onDelete(c.id, c.code)}
                            className="text-xs px-2.5 py-1 rounded-lg border border-red-200 text-red-500 hover:bg-red-50">
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                    {redemptions[c.id] && (
                      <tr className="border-t border-purple-50 bg-purple-50/30">
                        <td colSpan={8} className="px-4 py-3">
                          {redemptions[c.id].length === 0 ? (
                            <p className="text-xs text-warm-400">No redemptions yet.</p>
                          ) : (
                            <table className="w-full text-xs">
                              <thead className="text-warm-400">
                                <tr>
                                  <th className="text-left py-1 pr-4">Email</th>
                                  <th className="text-left py-1 pr-4">Card</th>
                                  <th className="text-left py-1 pr-4">Before</th>
                                  <th className="text-left py-1 pr-4">After</th>
                                  <th className="text-left py-1 pr-4">Date</th>
                                </tr>
                              </thead>
                              <tbody>
                                {redemptions[c.id].map(r => (
                                  <tr key={r.id} className="border-t border-purple-100/60">
                                    <td className="py-1.5 pr-4">{r.email || '—'}</td>
                                    <td className="py-1.5 pr-4">{r.card_slug || '(credit pack)'}</td>
                                    <td className="py-1.5 pr-4">{r.amount_before_ngn != null ? `₦${r.amount_before_ngn.toLocaleString()}` : '—'}</td>
                                    <td className="py-1.5 pr-4">{r.amount_after_ngn != null ? `₦${r.amount_after_ngn.toLocaleString()}` : '—'}</td>
                                    <td className="py-1.5 pr-4">{r.created_at ? format(new Date(r.created_at), 'MMM d, h:mm a') : '—'}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          )}
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

const Admin = () => {
  useSEO({ title: 'Admin Panel — Thankeeu', noIndex: true });

  const { user } = useAuth();
  const [loading, setLoading]           = useState(true);
  const [tab, setTab]                   = useState('overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Core data
  const [stats, setStats]               = useState({});
  const [users, setUsers]               = useState([]);
  const [cards, setCards]               = useState([]);
  const [redeliveringId, setRedeliveringId] = useState(null);

  // Lazy-loaded tabs
  const [companies, setCompanies]       = useState([]);
  const [companiesLoading, setCompaniesLoading] = useState(false);
  const [companyMembers, setCompanyMembers] = useState({});
  const [openCompany, setOpenCompany]   = useState(null);

  const [tickets, setTickets]           = useState([]);
  const [ticketsLoading, setTicketsLoading] = useState(false);
  const [openTicket, setOpenTicket]     = useState(null);
  const [replyText, setReplyText]       = useState('');
  const [replying, setReplying]         = useState(false);

  const [demos, setDemos]               = useState([]);
  const [demosLoading, setDemosLoading] = useState(false);
  const [editDemoId, setEditDemoId]     = useState(null);
  const [demoNote, setDemoNote]         = useState('');

  const [visitors, setVisitors]         = useState([]);
  const [visitorsLoading, setVisitorsLoading] = useState(false);
  const [nudging, setNudging] = useState(false);
  const [visitorStats, setVisitorStats] = useState(null);
  const [analytics, setAnalytics]       = useState(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [analyticsDays, setAnalyticsDays] = useState(30);
  const [countryVisits, setCountryVisits]   = useState([]);
  const [countryVisitsLoading, setCountryVisitsLoading] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState(null); // null = all

  const [blogPosts, setBlogPosts]       = useState([]);
  const [blogLoading, setBlogLoading]   = useState(false);
  const [blogEditing, setBlogEditing]   = useState(null);

  const [vendors,          setVendors]          = useState([]);
  const [vendorOrders,     setVendorOrders]     = useState([]);
  const [vendorsLoading,   setVendorsLoading]   = useState(false);
  const [palApplications,  setPalApplications]  = useState([]);
  const [discountCodes,    setDiscountCodes]    = useState([]);
  const [discountLoading,  setDiscountLoading]  = useState(false);
  const [discountRedemptions, setDiscountRedemptions] = useState({}); // { [codeId]: [redemption, ...] }
  const [palLoading,       setPalLoading]        = useState(false);
  const [palTickets,       setPalTickets]        = useState([]);
  const [rejectModal,      setRejectModal]       = useState(null);
  const [rejectReason,     setRejectReason]      = useState('');
  const [blogForm, setBlogForm]         = useState({
    title:'', excerpt:'', content:'', category:'General',
    tags:'', status:'draft', is_featured:false, cover_image:'',
    author_name:'Thankeeu Team',
  });
  const [blogSaving, setBlogSaving]     = useState(false);

  // ── Loaders ───────────────────────────────────────────────────────────────
  useEffect(() => { fetchCore(); }, []);

  useEffect(() => {
    if (tab === 'support'   && !tickets.length)       fetchTickets();
    if (tab === 'companies' && !companies.length)     fetchCompanies();
    if (tab === 'demos'     && !demos.length)         fetchDemos();
    if (tab === 'analytics' && !analytics) fetchAnalytics();
    if (tab === 'visitors'  && !visitors.length && !visitorStats) fetchVisitors();
    if (tab === 'blog'      && !blogPosts.length)     fetchBlog();
    if (tab === 'vendors'   && !vendors.length)      fetchVendors();
    if (tab === 'pals'      && !palApplications.length) fetchPals();
    if (tab === 'discounts' && !discountCodes.length)   fetchDiscountCodes();
  }, [tab]);

  const fetchCore = async () => {
    setLoading(true);
    try {
      const [statsRes, usersRes, cardsRes] = await Promise.all([
        adminAPI.getStats(), adminAPI.getUsers(), adminAPI.getCards(),
      ]);
      const statsData = statsRes.data || {};
      setStats(statsData.stats || statsData); // support both {stats:{...}} and flat shape
      setUsers(usersRes.data || []);
      setCards(cardsRes.data || []);
    } catch { toast.error('Failed to load admin data'); }
    finally { setLoading(false); }
  };

  const fetchTickets = async () => {
    setTicketsLoading(true);
    try { const r = await adminSupportAPI.getAll(); setTickets(r.data || []); }
    catch { toast.error('Failed to load tickets'); }
    finally { setTicketsLoading(false); }
  };

  const fetchCompanies = async () => {
    setCompaniesLoading(true);
    try { const r = await adminCompanyAPI.getAll(); setCompanies(r.data || []); }
    catch { toast.error('Failed to load companies'); }
    finally { setCompaniesLoading(false); }
  };

  const fetchDemos = async () => {
    setDemosLoading(true);
    try { const r = await demoAPI.getAll(); setDemos(Array.isArray(r.data) ? r.data : []); }
    catch (err) { toast.error('Failed to load demos'); setDemos([]); }
    finally { setDemosLoading(false); }
  };

  const fetchAnalytics = async (days = analyticsDays) => {
    setAnalyticsLoading(true);
    try {
      const base = import.meta.env.VITE_API_URL || '/api';
      const tok  = localStorage.getItem('thankeeu_token') || '';
      const r = await fetch(`${base}/analytics/dashboard?days=${days}`, { headers: { Authorization: `Bearer ${tok}` } });
      const d = await r.json();
      setAnalytics(d);
    } catch { toast.error('Failed to load analytics'); }
    finally { setAnalyticsLoading(false); }
  };

  const resetAnalytics = async () => {
    if (!window.confirm('This will permanently delete ALL page view records and reset the counter to zero. This cannot be undone. Continue?')) return;
    try {
      const base = import.meta.env.VITE_API_URL || '/api';
      const tok  = localStorage.getItem('thankeeu_token') || '';
      const r = await fetch(`${base}/analytics/reset`, { method: 'DELETE', headers: { Authorization: `Bearer ${tok}` } });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Reset failed');
      toast.success(d.message || 'Analytics reset to zero.');
      setAnalytics(null);
      fetchAnalytics(analyticsDays);
    } catch (e) { toast.error(e.message || 'Reset failed'); }
  };

  const fetchCountryVisits = async (country = selectedCountry, days = analyticsDays) => {
    setCountryVisitsLoading(true);
    try {
      const base = import.meta.env.VITE_API_URL || '/api';
      const tok  = localStorage.getItem('thankeeu_token') || '';
      const qs   = new URLSearchParams({ days, limit: 300, ...(country ? { country } : {}) });
      const r    = await fetch(`${base}/analytics/country-visits?${qs}`, { headers: { Authorization: `Bearer ${tok}` } });
      const d    = await r.json();
      setCountryVisits(Array.isArray(d) ? d : []);
    } catch { toast.error('Failed to load visit log'); }
    finally { setCountryVisitsLoading(false); }
  };

  const fetchVisitors = async () => {
    setVisitorsLoading(true);
    try {
      const tok  = localStorage.getItem('thankeeu_token');
      const base = import.meta.env.VITE_API_URL || '/api';
      // Visitors route is at /api/admin/visitors
      const r = await fetch(`${base}/admin/visitors`, { headers:{ Authorization:`Bearer ${tok}` } });
      if (!r.ok) throw new Error((await r.json())?.error || 'Failed');
      const data = await r.json();
      setVisitors(Array.isArray(data) ? data : []);

      // Also fetch visitor stats
      const rs = await fetch(`${base}/visitors/stats`, { headers:{ Authorization:`Bearer ${tok}` } });
      if (rs.ok) setVisitorStats(await rs.json());
    } catch (err) {
      console.error('fetchVisitors:', err);
      toast.error('Failed to load visitors');
      setVisitors([]);
    } finally { setVisitorsLoading(false); }
  };

  const sendNudge = async () => {
    if (!confirm('Send nudge emails to all eligible unconverted visitors now? This sends to visitors not nudged in 7 days and under 4 emails total.')) return;
    setNudging(true);
    try {
      const base = import.meta.env.VITE_API_URL || '/api';
      const res = await fetch(`${base}/admin/visitors/nudge`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${localStorage.getItem('thankeeu_token')}` },
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || 'Failed');
      toast.success(d.message || 'Nudge emails sent!');
      fetchVisitors(); // refresh visitor counts
    } catch (err) {
      toast.error(err.message || 'Nudge failed');
    } finally { setNudging(false); }
  };

  const fetchPals = async () => {
    setPalLoading(true);
    try {
      const base = import.meta.env.VITE_API_URL || '/api';
      const hdr  = { Authorization: `Bearer ${localStorage.getItem('thankeeu_token')}` };
      const [pRes, tRes] = await Promise.all([
        fetch(`${base}/admin/pals`, { headers: hdr }).then(r => r.json()),
        fetch(`${base}/admin/pals/tickets`, { headers: hdr }).then(r => r.json()).catch(() => []),
      ]);
      setPalApplications(Array.isArray(pRes) ? pRes : []);
      setPalTickets(Array.isArray(tRes) ? tRes : []);
    } catch { toast.error('Failed to load Pals data'); }
    finally { setPalLoading(false); }
  };

  const adminHeaders = () => ({ Authorization: `Bearer ${localStorage.getItem('thankeeu_token')}` });
  const adminBase = () => import.meta.env.VITE_API_URL || '/api';

  const fetchDiscountCodes = async () => {
    setDiscountLoading(true);
    try {
      const res = await fetch(`${adminBase()}/admin/discount-codes`, { headers: adminHeaders() }).then(r => r.json());
      setDiscountCodes(Array.isArray(res.codes) ? res.codes : []);
    } catch { toast.error('Failed to load discount codes'); }
    finally { setDiscountLoading(false); }
  };

  const createDiscountCode = async (payload) => {
    try {
      const res = await fetch(`${adminBase()}/admin/discount-codes`, {
        method: 'POST',
        headers: { ...adminHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || 'Could not create code'); return false; }
      toast.success(`Code "${data.code.code}" created`);
      setDiscountCodes(prev => [data.code, ...prev]);
      return true;
    } catch { toast.error('Could not create code'); return false; }
  };

  const toggleDiscountCode = async (id, patch) => {
    try {
      const res = await fetch(`${adminBase()}/admin/discount-codes/${id}`, {
        method: 'PUT',
        headers: { ...adminHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || 'Could not update code'); return; }
      setDiscountCodes(prev => prev.map(c => c.id === id ? data.code : c));
    } catch { toast.error('Could not update code'); }
  };

  const deleteDiscountCode = async (id, code) => {
    if (!window.confirm(`Delete discount code "${code}"? This cannot be undone.`)) return;
    try {
      const res = await fetch(`${adminBase()}/admin/discount-codes/${id}`, { method: 'DELETE', headers: adminHeaders() });
      if (!res.ok) { const d = await res.json(); toast.error(d.error || 'Could not delete code'); return; }
      toast.success('Code deleted');
      setDiscountCodes(prev => prev.filter(c => c.id !== id));
    } catch { toast.error('Could not delete code'); }
  };

  const loadRedemptions = async (id) => {
    if (discountRedemptions[id]) { // already loaded — just toggle visibility handled in render
      setDiscountRedemptions(prev => ({ ...prev, [id]: undefined }));
      return;
    }
    try {
      const res = await fetch(`${adminBase()}/admin/discount-codes/${id}/redemptions`, { headers: adminHeaders() }).then(r => r.json());
      setDiscountRedemptions(prev => ({ ...prev, [id]: Array.isArray(res.redemptions) ? res.redemptions : [] }));
    } catch { toast.error('Could not load redemptions'); }
  };

  const approvePal = async (id, name) => {
    const base = import.meta.env.VITE_API_URL||'/api';
    const res = await fetch(`${base}/admin/pals/${id}/approve`, { method:'POST', headers:{Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`} });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error||'Failed');
    toast.success(d.message || `${name} approved!`);
    fetchPals();
  };

  const rejectPal = async () => {
    if (!rejectReason.trim()) return toast.error('Please provide a reason');
    const base = import.meta.env.VITE_API_URL||'/api';
    const res = await fetch(`${base}/admin/pals/${rejectModal.id}/reject`, {
      method:'POST', headers:{'Content-Type':'application/json',Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`},
      body: JSON.stringify({ reason: rejectReason })
    });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error||'Failed');
    toast.success(d.message);
    setRejectModal(null); setRejectReason('');
    fetchPals();
  };

  const replyPalTicket = async (id, reply) => {
    const base = import.meta.env.VITE_API_URL||'/api';
    const res = await fetch(`${base}/admin/pals/tickets/${id}/reply`, {
      method:'PUT', headers:{'Content-Type':'application/json',Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`},
      body: JSON.stringify({ reply })
    });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error||'Failed');
    toast.success('Reply sent!');
    fetchPals();
  };

  const fetchVendors = async () => {
    setVendorsLoading(true);
    try {
      const base = import.meta.env.VITE_API_URL || '/api';
      const hdr  = { Authorization: `Bearer ${localStorage.getItem('thankeeu_token')}` };
      const [vRes, oRes] = await Promise.all([
        fetch(`${base}/vendor/admin/vendors`, { headers: hdr }).then(r => r.json()),
        fetch(`${base}/vendor/admin/orders`,  { headers: hdr }).then(r => r.json()).catch(() => []),
      ]);
      setVendors(Array.isArray(vRes) ? vRes : []);
      setVendorOrders(Array.isArray(oRes) ? oRes : []);
    } catch { toast.error('Failed to load vendor data'); }
    finally { setVendorsLoading(false); }
  };

  const fetchBlog = async () => {
    setBlogLoading(true);
    try { const r = await blogAPI.admin.getPosts('all'); setBlogPosts(r.data || []); }
    catch { toast.error('Failed to load blog posts'); }
    finally { setBlogLoading(false); }
  };

  // ── Actions ───────────────────────────────────────────────────────────────
  const updateDemoStatus = async (id, status) => {
    try {
      await demoAPI.updateStatus(id, status, demoNote || undefined);
      setDemos(prev => prev.map(d => d.id === id ? { ...d, status, admin_note: demoNote || d.admin_note } : d));
      setEditDemoId(null); setDemoNote('');
      toast.success('Status updated');
    } catch { toast.error('Update failed'); }
  };

  const handleReply = async () => {
    if (!replyText.trim() || !openTicket) return;
    setReplying(true);
    try {
      await adminSupportAPI.reply(openTicket.id, replyText);
      setReplyText(''); setOpenTicket(null);
      toast.success('Reply sent');
    } catch { toast.error('Reply failed'); }
    finally { setReplying(false); }
  };

  const saveBlogPost = async () => {
    if (!blogForm.title?.trim()) return toast.error('Title required');
    setBlogSaving(true);
    try {
      if (blogEditing) {
        await blogAPI.admin.updatePost(blogEditing.id, blogForm);
        setBlogPosts(prev => prev.map(p => p.id === blogEditing.id ? { ...p, ...blogForm } : p));
        toast.success('Post updated');
      } else {
        const r = await blogAPI.admin.createPost(blogForm);
        setBlogPosts(prev => [r.data, ...prev]);
        toast.success('Post created');
      }
      setBlogEditing(null);
      setBlogForm({ title:'', excerpt:'', content:'', category:'General', tags:'', status:'draft', is_featured:false, cover_image:'', author_name:'Thankeeu Team' });
    } catch { toast.error('Save failed'); }
    finally { setBlogSaving(false); }
  };

  if (!user || user.role !== 'admin') return (
    <div className="min-h-screen flex items-center justify-center" style={{ background:'#F5F3FF' }}>
      <div className="text-center">
        <div className="text-5xl mb-4">🔒</div>
        <p className="text-warm-700 font-semibold">Admin access only</p>
      </div>
    </div>
  );

  if (loading) return (
    <div className="min-h-screen grid place-items-center" style={{ background:'#F5F3FF' }}>
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mx-auto mb-4" />
        <p className="text-warm-500">Loading admin panel...</p>
      </div>
    </div>
  );

  const openTickets = tickets.filter(t => t.status === 'open' || t.status === 'in_progress');
  const newDemos    = demos.filter(d => d.status === 'new');

  const TABS = [
    { id:'overview',  label:'Overview' },
    { id:'users',     label:`Users (${users.length})` },
    { id:'cards',     label:`Cards (${cards.length})` },
    { id:'companies', label:'Companies' },
    { id:'games',     label:'Games League' },
    { id:'support',   label:`Support${openTickets.length ? ` · ${openTickets.length}` : ''}` },
    { id:'demos',     label:`Demos${newDemos.length ? ` · ${newDemos.length} new` : ''}` },
    { id:'analytics', label:'📊 Analytics' },
    { id:'visitors',  label:`Visitors${visitors.length ? ` (${visitors.length})` : ''}` },
    { id:'blog',      label:'Blog' },
    { id:'vendors',   label:'Vendors' },
    { id:'pals',      label:`Pals${palApplications.filter(p=>p.status==='pending').length ? ` · ${palApplications.filter(p=>p.status==='pending').length} new` : ''}` },
    { id:'discounts', label:'Discount Codes' },
  ];

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'#0F0B1E', color:'#fff', fontFamily:'inherit' }}>

      {/* ── DESKTOP SIDEBAR — always visible on lg+ ── */}
      <aside className="hidden lg:flex" style={{
        width:240, flexShrink:0,
        background:'linear-gradient(180deg,#1A1030 0%,#110820 100%)',
        borderRight:'1px solid rgba(139,92,246,0.15)',
        flexDirection:'column',
        position:'sticky', top:0, height:'100vh',
        overflowX:'hidden', overflowY:'auto', zIndex:50,
      }}>
        {/* Logo */}
        <div style={{ padding:'22px 14px 18px', display:'flex', alignItems:'center', gap:11, borderBottom:'1px solid rgba(139,92,246,0.12)', minHeight:72 }}>
          <img src="/android-chrome-192x192.png" alt="Thankeeu" style={{ width:36, height:36, borderRadius:9, flexShrink:0, objectFit:'cover' }} />
          <div style={{ overflow:'hidden', whiteSpace:'nowrap' }}>
            <p style={{ fontWeight:800, fontSize:15, margin:0, background:'linear-gradient(90deg,#A78BFA,#F472B6)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>Thankeeu</p>
            <p style={{ fontSize:10, color:'rgba(255,255,255,0.3)', letterSpacing:'0.12em', textTransform:'uppercase', margin:0 }}>Admin Panel</p>
          </div>
        </div>
        <nav style={{ flex:1, padding:'10px 8px', overflowY:'auto', overflowX:'hidden' }}>
          {[
            { id:'overview',  icon:'⚡', label:'Overview',      badge:null },
            { id:'analytics', icon:'📊', label:'Analytics',     badge:null },
            { id:'users',     icon:'👥', label:'Users',         badge:users.length||null },
            { id:'cards',     icon:'🃏', label:'Cards',         badge:cards.length||null },
            { id:'companies', icon:'🏢', label:'Companies',     badge:null },
            { id:'games',     icon:'GL', label:'Games League',  badge:null },
            { id:'support',   icon:'🎧', label:'Support',       badge:openTickets.length||null },
            { id:'broadcast', icon:'📣', label:'Broadcast',     badge:null },
            { id:'demos',     icon:'🚀', label:'Demo Requests', badge:newDemos.length||null },
            { id:'visitors',  icon:'👣', label:'Visitors',      badge:visitors.length||null },
            { id:'blog',      icon:'✍️', label:'Blog',          badge:null },
            { id:'vendors',   icon:'🏪', label:'Vendors',       badge:null },
            { id:'pals',      icon:'🤝', label:'Pals',          badge:palApplications.filter(p=>p.status==='pending').length||null },
            { id:'discounts', icon:'🎟', label:'Discount Codes', badge:null },
            { id:'coverdesigns', icon:'🎨', label:'Cover Design', badge:null },
            { id:'settings',  icon:'🎵', label:'Settings',       badge:null },
          ].map(item => {
            const active = tab === item.id;
            const isAlert = (item.id==='support'||item.id==='demos') && item.badge > 0;
            return (
              <button key={item.id} onClick={() => item.id === 'games' ? (window.location.href = '/admin/games') : setTab(item.id)}
                style={{
                  width:'100%', display:'flex', alignItems:'center', gap:10,
                  padding:'9px 12px', borderRadius:10, border:'none', cursor:'pointer', marginBottom:2,
                  background: active ? 'rgba(124,58,237,0.25)' : 'transparent',
                  color: active ? '#C4B5FD' : 'rgba(255,255,255,0.45)',
                  boxShadow: active ? 'inset 0 0 0 1px rgba(139,92,246,0.3)' : 'none',
                  transition:'all .12s', textAlign:'left', position:'relative',
                }}>
                {active && <div style={{ position:'absolute', left:0, top:'18%', bottom:'18%', width:3, borderRadius:'0 3px 3px 0', background:'linear-gradient(180deg,#7C3AED,#EC4899)' }} />}
                <span style={{ fontSize:16, flexShrink:0 }}>{item.icon}</span>
                <span style={{ fontSize:13, fontWeight:active?700:500, flex:1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{item.label}</span>
                {item.badge > 0 && <span style={{ background:isAlert?'#EF4444':'rgba(139,92,246,0.55)', color:'#fff', fontSize:10, fontWeight:700, padding:'1px 6px', borderRadius:20, flexShrink:0 }}>{item.badge}</span>}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* ── MOBILE/TABLET SIDEBAR — hamburger drawer on < lg ── */}
      {mobileSidebarOpen && (
        <div onClick={() => setMobileSidebarOpen(false)}
          style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.6)', zIndex:49, backdropFilter:'blur(2px)' }}
          className="lg:hidden" />
      )}
      <aside className="lg:hidden" style={{
        position:'fixed', top:0, left: mobileSidebarOpen ? 0 : '-280px',
        width:260, height:'100vh', zIndex:50,
        background:'linear-gradient(180deg,#1A1030 0%,#110820 100%)',
        borderRight:'1px solid rgba(139,92,246,0.15)',
        display:'flex', flexDirection:'column',
        transition:'left .28s cubic-bezier(.4,0,.2,1)',
        overflowX:'hidden', overflowY:'auto',
      }}>
        <div style={{ padding:'22px 14px 18px', display:'flex', alignItems:'center', gap:11, borderBottom:'1px solid rgba(139,92,246,0.12)' }}>
          <img src="/android-chrome-192x192.png" alt="Thankeeu" style={{ width:36, height:36, borderRadius:9, flexShrink:0, objectFit:'cover' }} />
          <div>
            <p style={{ fontWeight:800, fontSize:15, margin:0, background:'linear-gradient(90deg,#A78BFA,#F472B6)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>Thankeeu</p>
            <p style={{ fontSize:10, color:'rgba(255,255,255,0.3)', letterSpacing:'0.12em', textTransform:'uppercase', margin:0 }}>Admin Panel</p>
          </div>
          <button type="button" onClick={() => setMobileSidebarOpen(false)} aria-label="Close admin navigation" style={{ marginLeft:'auto', background:'none', border:'none', color:'rgba(255,255,255,0.4)', cursor:'pointer', padding:4, display:'inline-flex' }}><Icon name="X" size={18} /></button>
        </div>
        <nav style={{ flex:1, padding:'10px 8px', overflowY:'auto' }}>
          {[
            { id:'overview',  icon:'Zap', label:'Overview',      badge:null },
            { id:'analytics', icon:'BarChart2', label:'Analytics', badge:null },
            { id:'users',     icon:'Users', label:'Users',        badge:users.length||null },
            { id:'cards',     icon:'CreditCard', label:'Cards',   badge:cards.length||null },
            { id:'companies', icon:'Building2', label:'Companies', badge:null },
            { id:'games',     icon:'GL', label:'Games League',  badge:null },
            { id:'support',   icon:'MessageCircle', label:'Support', badge:openTickets.length||null },
            { id:'broadcast', icon:'Send', label:'Broadcast', badge:null },
            { id:'demos',     icon:'Rocket', label:'Demo Requests', badge:newDemos.length||null },
            { id:'visitors',  icon:'Users', label:'Visitors', badge:visitors.length||null },
            { id:'blog',      icon:'PenLine', label:'Blog', badge:null },
            { id:'vendors',   icon:'Store', label:'Vendors', badge:null },
            { id:'pals',      icon:'HeartHandshake', label:'Pals', badge:palApplications.filter(p=>p.status==='pending').length||null },
            { id:'discounts', icon:'Tag', label:'Discount Codes', badge:null },
            { id:'coverdesigns', icon:'Image', label:'Cover Design', badge:null },
            { id:'settings',  icon:'Settings', label:'Settings', badge:null },
          ].map(item => {
            const active = tab === item.id;
            const isAlert = (item.id==='support'||item.id==='demos') && item.badge > 0;
            return (
              <button key={item.id} onClick={() => { if (item.id === 'games') { window.location.href = '/admin/games'; return; } setTab(item.id); setMobileSidebarOpen(false); }}
                style={{ width:'100%', display:'flex', alignItems:'center', gap:10, padding:'10px 12px', borderRadius:10, border:'none', cursor:'pointer', marginBottom:2, background:active?'rgba(124,58,237,0.25)':'transparent', color:active?'#C4B5FD':'rgba(255,255,255,0.55)', textAlign:'left', position:'relative' }}>
                {active && <div style={{ position:'absolute', left:0, top:'20%', bottom:'20%', width:3, borderRadius:'0 3px 3px 0', background:'linear-gradient(180deg,#7C3AED,#EC4899)' }} />}
                <span style={{ display:'inline-flex' }}><Icon name={item.icon} size={16} /></span>
                <span style={{ fontSize:13, fontWeight:active?700:500, flex:1 }}>{item.label}</span>
                {item.badge > 0 && <span style={{ background:isAlert?'#EF4444':'rgba(139,92,246,0.55)', color:'#fff', fontSize:10, fontWeight:700, padding:'1px 6px', borderRadius:20 }}>{item.badge}</span>}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* MAIN */}
      <main style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', background:'linear-gradient(160deg,#F8F5FF 0%,#FDFCFF 100%)' }}>

        {/* Mobile/tablet topbar — hamburger, hidden on desktop */}
        <div className="lg:hidden" style={{ padding:'12px 16px', borderBottom:'1px solid #EDE9FF', background:'rgba(255,255,255,0.98)', display:'flex', alignItems:'center', justifyContent:'space-between', position:'sticky', top:0, zIndex:30 }}>
          <button type="button" onClick={() => setMobileSidebarOpen(true)} aria-label="Open admin navigation" style={{ width:40, height:40, borderRadius:10, border:'none', background:'linear-gradient(135deg,#7C3AED,#EC4899)', color:'white', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}><Icon name="Menu" size={19} /></button>
          <span style={{ fontWeight:800, fontSize:15, color:'#1a1a2e' }}>Admin Panel</span>
          <button type="button" onClick={fetchCore} aria-label="Refresh admin data" style={{ width:40, height:40, borderRadius:10, border:'1px solid #DDD6FE', background:'white', color:'#7C3AED', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}><Icon name="Refresh" size={16} /></button>
        </div>

        {/* Desktop topbar — tab title + actions, hidden on mobile/tablet */}
        <div className="hidden lg:flex" style={{ padding:'14px 28px', borderBottom:'1px solid #EDE9FF', background:'rgba(255,255,255,0.96)', backdropFilter:'blur(8px)', alignItems:'center', justifyContent:'space-between', position:'sticky', top:0, zIndex:30 }}>
          <div>
            <h1 style={{ margin:0, fontSize:19, fontWeight:800, color:'#1a1a2e' }}>
              {({'overview':'Overview','analytics':'Analytics','users':'Users','cards':'Cards','companies':'Companies','broadcast':'Broadcast','support':'Support','demos':'Demo Requests','visitors':'Visitors','blog':'Blog','vendors':'Vendors','pals':'Pals','discounts':'Discount Codes','coverdesigns':'Cover Design','settings':'Settings'})[tab] || tab}
            </h1>
            <p style={{ margin:'2px 0 0', fontSize:11, color:'#9CA3AF' }}>Signed in as {user?.full_name}</p>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button type="button" onClick={fetchCore} style={{ padding:'8px 14px', borderRadius:10, border:'1px solid #DDD6FE', background:'white', color:'#7C3AED', fontSize:12, fontWeight:700, cursor:'pointer', display:'inline-flex', alignItems:'center', gap:6 }}><Icon name="Refresh" size={13} />Refresh</button>
            <button onClick={() => { localStorage.removeItem('thankeeu_token'); localStorage.removeItem('thankeeu_user'); window.location.href='/admin/login'; }}
              style={{ padding:'8px 14px', borderRadius:10, border:'none', background:'#FEE2E2', color:'#DC2626', fontSize:12, fontWeight:700, cursor:'pointer' }}>Sign out</button>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{ padding:'10px 16px', background:'white', borderBottom:'1px solid #F3EEFF', display:'flex', gap:10, overflowX:'auto' }} className='md:flex-wrap md:px-28'>
          {[
            { icon:'👥', val:(stats.total_users||0).toLocaleString(),        label:'Users',       color:'#7C3AED' },
            { icon:'🃏', val:(stats.total_cards||0).toLocaleString(),        label:'Cards',       color:'#2563EB' },
            { icon:'✅', val:(stats.sent_cards||0).toLocaleString(),         label:'Sent',        color:'#059669' },
            { icon:'✍️', val:(stats.total_messages||0).toLocaleString(),     label:'Messages',    color:'#0891B2' },
            { icon:'💰', val:formatNGN(stats.total_gift_volume||0),          label:'Gift volume', color:'#D97706' },
          ].map(s => (
            <div key={s.label} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 16px', borderRadius:12, background:'#FAFAFF', border:'1px solid #EDE9FF', flex:'1 1 140px' }}>
              <span style={{ fontSize:20 }}>{s.icon}</span>
              <div>
                <p style={{ margin:0, fontSize:17, fontWeight:800, color:s.color, lineHeight:1 }}>{s.val}</p>
                <p style={{ margin:0, fontSize:11, color:'#9CA3AF', marginTop:1 }}>{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex:1, padding:'16px', overflowY:'auto' }} className="admin-content md:p-7">
          <style>{`
            .admin-content .input{background:white;border:1px solid #DDD6FE;border-radius:10px;padding:8px 12px;font-size:14px;outline:none;width:100%;color:#1a1a2e;}
            .admin-content .input:focus{border-color:#7C3AED;box-shadow:0 0 0 3px rgba(124,58,237,0.1);}
            .admin-content .btn-secondary{background:white;border:1px solid #DDD6FE;border-radius:10px;padding:8px 14px;font-size:13px;font-weight:600;color:#6D28D9;cursor:pointer;}
            .admin-content .btn-secondary:hover{background:#F5F3FF;}
            .admin-content table{width:100%;border-collapse:collapse;}
            .admin-content th{text-align:left;font-size:11px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.08em;padding:10px 14px;border-bottom:2px solid #F3EEFF;background:white;}
            .admin-content td{padding:11px 14px;border-bottom:1px solid #F9F7FF;font-size:13px;color:#374151;vertical-align:middle;}
            .admin-content tr:hover td{background:#FDFCFF;}
            .admin-content .card-box{background:white;border-radius:16px;border:1px solid #EDE9FF;overflow:hidden;margin-bottom:20px;}
            .admin-content h2{font-size:18px;font-weight:800;color:#1a1a2e;margin:0 0 16px;}
            .admin-content h3{font-size:15px;font-weight:700;color:#1a1a2e;margin:0 0 12px;}
            .admin-content .bg-white{background:white;}
            .admin-content .rounded-2xl{border-radius:16px;}
            .admin-content .border{border:1px solid #EDE9FF;}
            .admin-content .border-warm-100{border-color:#EDE9FF;}
            .admin-content .p-5{padding:20px;}
            .admin-content .space-y-6>*+*{margin-top:24px;}
            .admin-content .space-y-4>*+*{margin-top:16px;}
            .admin-content .space-y-3>*+*{margin-top:12px;}
            .admin-content .space-y-2>*+*{margin-top:8px;}
            .admin-content .text-warm-900{color:#1a1a2e;}
            .admin-content .text-warm-700{color:#374151;}
            .admin-content .text-warm-500{color:#6B7280;}
            .admin-content .text-warm-400{color:#9CA3AF;}
          `}</style>
{/* ─────────────── OVERVIEW ─────────────── */}
        {tab === 'overview' && (
          <div className="grid md:grid-cols-2 gap-6">
            {/* Recent signups */}
            <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
              <div className="px-5 py-4 border-b border-purple-50 flex items-center justify-between">
                <p className="font-bold text-warm-900 text-sm">Recent signups</p>
                <Badge color="purple">{users.length} total</Badge>
              </div>
              <div className="divide-y divide-purple-50">
                {users.slice(0, 8).map(u => (
                  <div key={u.id} className="flex items-center gap-3 px-5 py-3 hover:bg-purple-50/30">
                    <div className="w-8 h-8 bg-primary-100 rounded-xl flex items-center justify-center text-primary-600 text-xs font-bold flex-shrink-0">
                      {u.full_name?.charAt(0) || '?'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-warm-800 truncate">{u.full_name}</p>
                      <p className="text-xs text-warm-400 truncate">{u.email}</p>
                    </div>
                    <Badge color={u.role === 'admin' ? 'purple' : 'gray'}>{u.role}</Badge>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent cards */}
            <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
              <div className="px-5 py-4 border-b border-purple-50 flex items-center justify-between">
                <p className="font-bold text-warm-900 text-sm">Recent cards</p>
                <Badge color="green">{cards.filter(c=>c.status==='sent').length} sent</Badge>
              </div>
              <div className="divide-y divide-purple-50">
                {cards.slice(0, 8).map(c => (
                  <div key={c.id} className="flex items-center gap-3 px-5 py-3 hover:bg-purple-50/30">
                    <div className="w-8 h-8 bg-pink-100 rounded-xl flex items-center justify-center text-pink-600 text-sm flex-shrink-0">💌</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-warm-800 truncate">{c.title || `For ${c.recipient_name}`}</p>
                      <p className="text-xs text-warm-400 truncate">{c.occasion} · {c.creator_name}</p>
                    </div>
                    <Badge color={c.status==='sent'?'green':c.status==='active'?'blue':'gray'}>{c.status}</Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ─────────────── BROADCAST ─────────────── */}
        {tab === 'broadcast' && <BroadcastTab />}

        {/* ─────────────── USERS ─────────────── */}
        {tab === 'users' && <UsersTab users={users} setUsers={setUsers} />}

        {/* ─────────────── CARDS ─────────────── */}
        {tab === 'cards' && (
          <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ background:'#F8F6FF' }}>
                  <tr>{['Card','Creator','Occasion','Status','Gift','Created',''].map(h=>(
                    <th key={h} className="text-left px-4 py-3 text-xs font-bold text-warm-500 uppercase tracking-wide">{h}</th>
                  ))}</tr>
                </thead>
                <tbody className="divide-y divide-purple-50">
                  {cards.map(c => (
                    <tr key={c.id} className="hover:bg-purple-50/30">
                      <td className="px-4 py-3 text-sm font-semibold text-warm-800 max-w-[180px] truncate">{c.title || `For ${c.recipient_name}`}</td>
                      <td className="px-4 py-3 text-xs text-warm-500">{c.creator_name}</td>
                      <td className="px-4 py-3 text-xs text-warm-500 capitalize">{c.occasion?.replace('_',' ')}</td>
                      <td className="px-4 py-3">
                        <Badge color={c.status==='sent'?'green':c.status==='active'?'blue':'gray'}>{c.status}</Badge>
                        {c.redelivery_count > 0 && (
                          <span className="ml-1.5 text-[10px] font-semibold text-warm-400" title={c.last_redelivered_at ? `Last re-delivered ${format(new Date(c.last_redelivered_at), 'MMM d, h:mma')}` : undefined}>
                            ↻{c.redelivery_count}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs font-semibold text-green-700">{c.total_collected ? formatNGN(c.total_collected) : '—'}</td>
                      <td className="px-4 py-3 text-xs text-warm-400">{c.created_at ? format(new Date(c.created_at),'MMM d') : '—'}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {c.status === 'sent' && (
                          <button
                            disabled={redeliveringId === c.id}
                            title="Re-deliver to recipient with any new signatures & gifts"
                            onClick={async () => {
                              if (!confirm(`Re-deliver "${c.title || `For ${c.recipient_name}`}" to ${c.recipient_email || 'the recipient'}?\n\nThis sends a fresh email including any new signatures and gift money that came in since the last delivery.`)) return;
                              setRedeliveringId(c.id);
                              try {
                                const res = await adminAPI.redeliverCard(c.id);
                                const { new_messages = 0, new_gift_amount = 0, redelivery_count, last_redelivered_at } = res.data || {};
                                setCards(prev => prev.map(x => x.id === c.id ? { ...x, redelivery_count, last_redelivered_at } : x));
                                const extras = [];
                                if (new_messages) extras.push(`${new_messages} new message${new_messages===1?'':'s'}`);
                                if (new_gift_amount) extras.push(`${formatNGN(new_gift_amount)} in new gifts`);
                                toast.success(extras.length ? `Re-delivered — included ${extras.join(' & ')}` : 'Re-delivered to recipient');
                              } catch (err) {
                                toast.error(err.response?.data?.error || 'Could not re-deliver this card');
                              } finally {
                                setRedeliveringId(null);
                              }
                            }}
                            className="text-xs text-primary-600 hover:bg-primary-50 px-2 py-1 rounded-lg disabled:opacity-40 mr-1"
                          >
                            {redeliveringId === c.id ? '…' : '🔁'}
                          </button>
                        )}
                        <button onClick={async()=>{
                          if(!confirm('Delete this card?')) return;
                          await adminAPI.deleteCard(c.id);
                          setCards(p=>p.filter(x=>x.id!==c.id));
                          toast.success('Card deleted');
                        }} className="text-xs text-red-400 hover:bg-red-50 px-2 py-1 rounded-lg">🗑️</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ─────────────── COMPANIES ─────────────── */}
        {tab === 'companies' && (
          <div className="space-y-3">
            {companiesLoading ? [...Array(4)].map((_,i)=><div key={i} className="h-20 rounded-2xl animate-pulse bg-purple-50"/>)
            : companies.length === 0 ? <EmptyState icon="🏢" title="No companies yet" sub="Companies appear here when HR teams sign up" />
            : companies.map(co => (
              <div key={co.id} className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
                <div className="flex items-center gap-4 px-5 py-4 cursor-pointer hover:bg-purple-50/30"
                  onClick={async () => {
                    if (openCompany === co.id) { setOpenCompany(null); return; }
                    setOpenCompany(co.id);
                    if (!companyMembers[co.id]) {
                      const r = await adminCompanyAPI.getMembers(co.id).catch(()=>({data:[]}));
                      setCompanyMembers(p=>({...p,[co.id]: r.data||[]}));
                    }
                  }}>
                  <div className="w-10 h-10 rounded-xl bg-primary-100 flex items-center justify-center text-primary-600 font-bold text-lg flex-shrink-0">
                    {co.name?.[0]||'?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-warm-900 text-sm">{co.name}</p>
                    <p className="text-xs text-warm-400">{co.email} · {co.industry || 'No industry'}</p>
                  </div>
                  <Badge color={co.subscription_status==='active'?'green':'gray'}>
                    {co.subscription_status==='active' ? `✓ ${co.subscription_plan}` : 'free'}
                  </Badge>
                  <span className="text-warm-400 text-sm">{openCompany===co.id?'▲':'▼'}</span>
                </div>
                {openCompany===co.id && (
                  <div className="border-t border-purple-50 px-5 py-4 bg-purple-50/30 space-y-4">
                    <p className="text-xs font-semibold text-warm-500">
                      {(companyMembers[co.id]||[]).length} team members
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {(companyMembers[co.id]||[]).slice(0,10).map(m=>(
                        <span key={m.id} className="text-xs bg-white border border-purple-100 px-2 py-1 rounded-lg text-warm-700">
                          {m.first_name} {m.last_name}
                        </span>
                      ))}
                      {(companyMembers[co.id]||[]).length > 10 && (
                        <span className="text-xs text-warm-400">+{(companyMembers[co.id]||[]).length - 10} more</span>
                      )}
                    </div>

                    {/* ── Pricing Multiplier ──────────────────────────── */}
                    <div className="bg-white border border-purple-100 rounded-xl p-4">
                      <p className="text-xs font-bold text-warm-700 mb-2">💰 Set pricing multiplier</p>
                      <p className="text-xs text-warm-400 mb-3">Rate per employee per month. 0 = free plan. Leave blank = "get a quote" shown to HR.</p>
                      <div className="flex gap-2 items-center">
                        <span className="text-sm text-warm-500">₦</span>
                        <input type="number" min="0" placeholder="e.g. 2000"
                          defaultValue={co.pricing_multiplier ?? ''}
                          id={`mult-${co.id}`}
                          className="flex-1 border border-purple-200 rounded-lg px-3 py-1.5 text-sm text-warm-900 focus:outline-none focus:border-primary-400" />
                        <button
                          onClick={async () => {
                            const val = document.getElementById(`mult-${co.id}`)?.value;
                            if (val === '' || val === null) return toast.error('Enter a value (0 for free)');
                            try {
                              const r = await fetch(`${import.meta.env.VITE_API_URL||'/api'}/admin/companies/${co.id}/set-multiplier`, {
                                method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`},
                                body: JSON.stringify({ multiplier: Number(val) })
                              });
                              const d = await r.json();
                              if (!r.ok) throw new Error(d.error);
                              toast.success(d.message);
                            } catch(e) { toast.error(e.message); }
                          }}
                          className="bg-primary-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-primary-600">
                          Set
                        </button>
                      </div>
                      {co.pricing_multiplier === 0 && <p className="text-xs text-green-600 font-semibold mt-1">✓ Currently FREE</p>}
                      {co.pricing_multiplier > 0 && <p className="text-xs text-primary-600 font-semibold mt-1">✓ Currently ₦{co.pricing_multiplier?.toLocaleString('en-NG')}/employee/month</p>}
                    </div>

                    {/* ── Delete Company ───────────────────────────────── */}
                    <div className="bg-white border border-red-100 rounded-xl p-4">
                      <p className="text-xs font-bold text-red-700 mb-1">🗑️ Delete company account</p>
                      <p className="text-xs text-warm-400 mb-3">
                        Permanently deletes the company and ALL associated data — team members,
                        cards, occasions, subscriptions, HRIS connections. This cannot be undone.
                        HR can then re-register with the same email without duplicate issues.
                      </p>
                      <button
                        onClick={async () => {
                          const confirm1 = window.confirm(`⚠️ Delete "${co.name}"?\n\nThis will permanently remove:\n• All team members\n• All cards and messages\n• All occasion settings\n• All subscriptions and HRIS connections\n\nHR can re-register afterwards with the same email.\n\nType the company name to confirm in the next prompt.`);
                          if (!confirm1) return;
                          const typed = window.prompt(`Type the company name exactly to confirm deletion:\n\n"${co.name}"`);
                          if (typed !== co.name) { toast.error('Company name did not match — deletion cancelled.'); return; }
                          try {
                            const r = await fetch(`${import.meta.env.VITE_API_URL||'/api'}/admin/companies/${co.id}`, {
                              method: 'DELETE',
                              headers: { Authorization: `Bearer ${localStorage.getItem('thankeeu_token')}` },
                            });
                            const d = await r.json();
                            if (!r.ok) throw new Error(d.error);
                            toast.success(d.message);
                            setCompanies(prev => prev.filter(c => c.id !== co.id));
                            setOpenCompany(null);
                          } catch(e) { toast.error(e.message || 'Failed to delete company'); }
                        }}
                        className="text-xs font-bold bg-red-50 border border-red-200 text-red-600 px-4 py-2 rounded-lg hover:bg-red-100 transition-colors">
                        🗑️ Delete company &amp; all data
                      </button>
                    </div>

                    {/* ── Pilot Period ─────────────────────────────────── */}
                    <div className="bg-white border border-purple-100 rounded-xl p-4">
                      <p className="text-xs font-bold text-warm-700 mb-2">🧪 Grant pilot period</p>
                      <p className="text-xs text-warm-400 mb-3">Company gets free access for the chosen duration. Automation stops after pilot ends.</p>
                      {co.pilot_ends_at && new Date(co.pilot_ends_at) > new Date() && (
                        <p className="text-xs text-green-600 font-semibold mb-2">
                          ✓ Pilot active until {new Date(co.pilot_ends_at).toLocaleDateString('en-NG')}
                        </p>
                      )}
                      <div className="flex gap-2">
                        {[14, 30].map(days => (
                          <button key={days}
                            onClick={async () => {
                              if (!confirm(`Grant ${days}-day pilot to ${co.name}?`)) return;
                              try {
                                const r = await fetch(`${import.meta.env.VITE_API_URL||'/api'}/admin/companies/${co.id}/grant-pilot`, {
                                  method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`},
                                  body: JSON.stringify({ days })
                                });
                                const d = await r.json();
                                if (!r.ok) throw new Error(d.error);
                                toast.success(d.message);
                              } catch(e) { toast.error(e.message); }
                            }}
                            className="text-xs font-bold border border-primary-200 text-primary-600 px-4 py-1.5 rounded-lg hover:bg-primary-50">
                            {days}-day pilot
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ─────────────── SUPPORT ─────────────── */}
        {tab === 'support' && (
          <div className="space-y-3">
            {ticketsLoading ? [...Array(3)].map((_,i)=><div key={i} className="h-20 rounded-2xl animate-pulse bg-purple-50"/>)
            : tickets.length === 0 ? <EmptyState icon="💬" title="No support tickets" sub="All clear!" />
            : tickets.map(t => (
              <div key={t.id} className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
                <div className="flex items-start gap-4 px-5 py-4 cursor-pointer hover:bg-purple-50/30" onClick={()=>setOpenTicket(openTicket?.id===t.id?null:t)}>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <p className="font-semibold text-warm-900 text-sm">{t.subject}</p>
                      <Badge color={ticketColor[t.status]||'gray'}>{t.status?.replace('_',' ')}</Badge>
                    </div>
                    <p className="text-xs text-warm-400">{t.user_name} · {t.user_email}</p>
                    <p className="text-xs text-warm-400 mt-0.5">{t.created_at ? format(new Date(t.created_at),'MMM d, yyyy · h:mm a') : '—'}</p>
                  </div>
                </div>
                {openTicket?.id===t.id && (
                  <div className="border-t border-purple-50 px-5 py-4 space-y-3">
                    <div className="bg-warm-50 rounded-xl p-3">
                      <p className="text-sm text-warm-700 leading-relaxed">{t.message}</p>
                    </div>
                    {t.replies?.map((r,i)=>(
                      <div key={i} className={`rounded-xl p-3 ${r.from_admin?'bg-primary-50 ml-4':'bg-warm-50 mr-4'}`}>
                        <p className="text-xs font-semibold text-warm-500 mb-1">{r.from_admin?'Admin':'User'} · {r.created_at ? format(new Date(r.created_at),'MMM d, h:mm a') : ''}</p>
                        <p className="text-sm text-warm-700">{r.message}</p>
                      </div>
                    ))}
                    <textarea className="input h-24 text-sm resize-none" placeholder="Write a reply..."
                      value={replyText} onChange={e=>setReplyText(e.target.value)} />
                    <div className="flex gap-2">
                      <button onClick={handleReply} disabled={replying||!replyText.trim()} className="btn-primary text-sm py-2 px-5">
                        {replying?'Sending…':'Send reply'}
                      </button>
                      <button onClick={()=>setOpenTicket(null)} className="btn-secondary text-sm py-2 px-4">Close</button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ─────────────── DEMOS ─────────────── */}
        {tab === 'demos' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex flex-wrap gap-2">
                {['new','contacted','scheduled','converted','declined'].map(s=>(
                  <Badge key={s} color={demoColor[s]||'gray'}>
                    {s} ({demos.filter(d=>d.status===s).length})
                  </Badge>
                ))}
              </div>
              <button onClick={fetchDemos} className="btn-secondary text-xs py-2 px-3">↻ Refresh</button>
            </div>

            {demosLoading ? [...Array(3)].map((_,i)=><div key={i} className="h-24 rounded-2xl animate-pulse bg-purple-50"/>)
            : demos.length === 0 ? (
              <EmptyState icon="📅" title="No demo requests yet" sub="Requests appear when companies fill in the Book Demo form on the homepage or pricing page" />
            ) : demos.map(d => (
              <div key={d.id} className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
                <div className="flex flex-col sm:flex-row sm:items-start gap-4 px-5 py-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <p className="font-bold text-warm-900 text-sm">{d.company_name}</p>
                      <Badge color={demoColor[d.status]||'gray'}>{d.status}</Badge>
                      {d.team_size && <Badge color="gray">{d.team_size} employees</Badge>}
                    </div>
                    <p className="text-xs text-warm-600 font-medium">{d.contact_name} · {d.email}{d.phone?` · ${d.phone}`:''}</p>
                    {d.message && <p className="text-xs text-warm-400 mt-1 line-clamp-2">{d.message}</p>}
                    {d.admin_note && (
                      <div className="mt-2 bg-primary-50 rounded-lg px-3 py-2">
                        <p className="text-xs text-primary-700"><strong>Note:</strong> {d.admin_note}</p>
                      </div>
                    )}
                    <p className="text-xs text-warm-400 mt-1.5">{d.created_at ? format(new Date(d.created_at),'MMM d, yyyy · h:mm a') : '—'}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 flex-shrink-0">
                    <a href={`mailto:${d.email}?subject=Thankeeu for Teams Demo - ${d.company_name}`}
                      className="text-xs bg-primary-50 text-primary-600 hover:bg-primary-100 px-3 py-2 rounded-xl font-semibold transition-colors">
                      📧 Email
                    </a>
                    <button onClick={()=>{setEditDemoId(editDemoId===d.id?null:d.id); setDemoNote(d.admin_note||'');}}
                      className="text-xs border border-purple-200 text-warm-600 hover:bg-warm-100 px-3 py-2 rounded-xl transition-colors">
                      ✏️ Update
                    </button>
                  </div>
                </div>
                {editDemoId===d.id && (
                  <div className="border-t border-purple-50 bg-purple-50/30 px-5 py-4 space-y-3">
                    <p className="text-xs font-semibold text-warm-600">Update status for {d.company_name}</p>
                    <div className="flex flex-wrap gap-2">
                      {['new','contacted','scheduled','converted','declined'].map(s=>(
                        <button key={s} onClick={()=>updateDemoStatus(d.id,s)}
                          className={`text-xs px-3 py-1.5 rounded-xl font-semibold border transition-all capitalize ${
                            d.status===s ? 'bg-primary-500 text-white border-primary-500' : 'bg-white border-purple-200 text-warm-600 hover:bg-purple-50'
                          }`}>{s}</button>
                      ))}
                    </div>
                    <textarea className="input text-sm resize-none h-16" placeholder="Admin note (optional)"
                      value={demoNote} onChange={e=>setDemoNote(e.target.value)} />
                    <button onClick={()=>updateDemoStatus(d.id, d.status)} className="btn-primary text-xs py-2 px-4">Save note</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ─────────────── VISITORS ─────────────── */}
        {tab === 'analytics' && (
          <div className="space-y-6">
            {/* Header + range picker */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-warm-900">Website Analytics</h2>
                <p className="text-sm text-warm-400">Page views and unique visitors to thankeeu.com</p>
              </div>
              <div className="flex gap-2">
                {[7,14,30,90].map(d => (
                  <button key={d}
                    onClick={() => { setAnalyticsDays(d); setAnalytics(null); fetchAnalytics(d); }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${analyticsDays===d ? 'bg-primary-600 text-white border-primary-600' : 'bg-white text-warm-600 border-warm-200 hover:border-primary-300'}`}>
                    {d}d
                  </button>
                ))}
                <button onClick={() => fetchAnalytics(analyticsDays)}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold border bg-white text-warm-600 border-warm-200 hover:border-primary-300 transition-colors">
                  ↻ Refresh
                </button>
                <button onClick={resetAnalytics}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold border bg-red-50 text-red-600 border-red-200 hover:bg-red-100 hover:border-red-400 transition-colors"
                  title="Delete all page view records and reset to zero">
                  🗑 Reset to 0
                </button>
              </div>
            </div>

            {analyticsLoading && <div className="text-center py-16 text-warm-400">Loading analytics…</div>}

            {analytics && !analyticsLoading && (
              <>
                {/* Summary cards */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                  {[
                    { label: 'Today views',      val: analytics.summary.todayViews,    color: 'text-blue-600',   bg: 'bg-blue-50' },
                    { label: 'Today visitors',   val: analytics.summary.todayUnique,   color: 'text-violet-600', bg: 'bg-violet-50' },
                    { label: 'Yesterday views',  val: analytics.summary.yesterdayViews,color: 'text-warm-600',   bg: 'bg-warm-50' },
                    { label: `${analyticsDays}d views`,  val: analytics.summary.totalViews,    color: 'text-emerald-600',bg: 'bg-emerald-50' },
                    { label: `${analyticsDays}d visitors`,val: analytics.summary.totalUnique,   color: 'text-pink-600',   bg: 'bg-pink-50' },
                  ].map(s => (
                    <div key={s.label} className={`${s.bg} rounded-2xl p-4`}>
                      <p className={`text-2xl font-extrabold ${s.color}`}>{s.val?.toLocaleString()}</p>
                      <p className="text-xs text-warm-500 mt-1">{s.label}</p>
                    </div>
                  ))}
                </div>

                {/* Daily bar chart — pure CSS/HTML, no library needed */}
                <div className="bg-white rounded-2xl border border-warm-100 p-5">
                  <h3 className="text-sm font-bold text-warm-700 mb-4">Daily Unique Visitors</h3>
                  <div className="overflow-x-auto">
                    <div style={{ minWidth: Math.max(600, analytics.chartData.length * 26), height: 160 }}
                      className="flex items-end gap-1 pb-6 relative">
                      {/* Y-axis guide lines */}
                      {[25,50,75,100].map(pct => {
                        const maxVal = Math.max(1, ...analytics.chartData.map(d => d.unique));
                        const lineVal = Math.round(maxVal * pct / 100);
                        return (
                          <div key={pct} className="absolute left-0 right-0 border-t border-warm-100 text-[9px] text-warm-300"
                            style={{ bottom: `${pct}%` }}>
                            <span className="pl-1">{lineVal}</span>
                          </div>
                        );
                      })}
                      {analytics.chartData.map((d, i) => {
                        const maxVal = Math.max(1, ...analytics.chartData.map(x => x.unique));
                        const heightPct = (d.unique / maxVal) * 100;
                        const isToday = d.day === new Date().toISOString().split('T')[0];
                        return (
                          <div key={i} className="flex flex-col items-center flex-1 group relative">
                            {/* Tooltip */}
                            <div className="absolute bottom-full mb-1 hidden group-hover:flex flex-col items-center z-10">
                              <div className="bg-warm-900 text-white text-[10px] rounded px-2 py-1 whitespace-nowrap">
                                {d.label}: {d.unique} visitors / {d.views} views
                              </div>
                            </div>
                            {/* Bar */}
                            <div className={`w-full rounded-t-sm transition-all ${isToday ? 'bg-primary-500' : 'bg-primary-200 group-hover:bg-primary-400'}`}
                              style={{ height: `${Math.max(2, heightPct)}%` }} />
                            {/* Label — show every nth */}
                            {(i % Math.ceil(analytics.chartData.length / 10) === 0 || isToday) && (
                              <span className={`text-[8px] mt-1 rotate-45 origin-left whitespace-nowrap ${isToday ? 'text-primary-600 font-bold' : 'text-warm-400'}`}>
                                {isToday ? 'Today' : d.label}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Views vs Visitors legend */}
                  <div className="flex gap-4 mt-2 text-xs text-warm-500">
                    <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm bg-primary-500 inline-block" /> Unique visitors (blue)</span>
                    <span className="text-warm-300">Hover bars for full data</span>
                  </div>
                </div>

                {/* Top pages + Top countries side by side */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Top pages */}
                  <div className="bg-white rounded-2xl border border-warm-100 p-5">
                    <h3 className="text-sm font-bold text-warm-700 mb-4">Top Pages</h3>
                    <div className="space-y-2">
                      {analytics.topPages.map((p, i) => {
                        const maxCount = analytics.topPages[0]?.count || 1;
                        const pct = Math.round((p.count / maxCount) * 100);
                        return (
                          <div key={i} className="flex items-center gap-3">
                            <span className="text-xs text-warm-400 w-5 text-right">{i+1}.</span>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-0.5">
                                <span className="text-xs font-medium text-warm-700 truncate">{p.path || '/'}</span>
                                <span className="text-xs font-bold text-warm-900 ml-2 flex-shrink-0">{p.count.toLocaleString()}</span>
                              </div>
                              <div className="h-1.5 bg-warm-100 rounded-full overflow-hidden">
                                <div className="h-full bg-primary-400 rounded-full" style={{ width: `${pct}%` }} />
                              </div>
                            </div>
                          </div>
                        );
                      })}
                      {analytics.topPages.length === 0 && (
                        <p className="text-sm text-warm-400 text-center py-4">No data yet — deploy the tracker first.</p>
                      )}
                    </div>
                  </div>

                  {/* Top countries — clickable to drill down */}
                  <div className="bg-white rounded-2xl border border-warm-100 p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-bold text-warm-700">🌍 Top Countries</h3>
                      {selectedCountry && (
                        <button onClick={() => { setSelectedCountry(null); setCountryVisits([]); }}
                          className="text-xs text-primary-500 hover:underline font-semibold">
                          ← All countries
                        </button>
                      )}
                    </div>
                    <div className="space-y-2">
                      {(analytics.topCountries || []).map((c, i) => {
                        const maxCount = analytics.topCountries[0]?.count || 1;
                        const pct = Math.round((c.count / maxCount) * 100);
                        const flag = c.country ? String.fromCodePoint(
                          ...[...c.country.toUpperCase()].slice(0,2).map(ch => 0x1F1E6 + ch.charCodeAt(0) - 65)
                        ) : '🌐';
                        const isSelected = selectedCountry === c.country;
                        return (
                          <button key={i}
                            onClick={() => {
                              const next = isSelected ? null : c.country;
                              setSelectedCountry(next);
                              fetchCountryVisits(next, analyticsDays);
                            }}
                            className={`w-full flex items-center gap-3 rounded-xl px-2 py-1.5 transition-colors text-left ${isSelected ? 'bg-primary-50 ring-1 ring-primary-200' : 'hover:bg-warm-50'}`}>
                            <span className="text-base w-6 flex-shrink-0">{flag}</span>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-0.5">
                                <span className="text-xs font-medium text-warm-700 truncate">{c.country || 'Unknown'}</span>
                                <span className="text-xs font-bold text-warm-900 ml-2 flex-shrink-0">{c.count.toLocaleString()}</span>
                              </div>
                              <div className="h-1.5 bg-warm-100 rounded-full overflow-hidden">
                                <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${pct}%` }} />
                              </div>
                            </div>
                            <span className="text-[10px] text-primary-400 flex-shrink-0">→</span>
                          </button>
                        );
                      })}
                      {!(analytics.topCountries?.length) && (
                        <p className="text-sm text-warm-400 text-center py-4">Country data starts appearing after first visitors.</p>
                      )}
                    </div>
                    {analytics.topCountries?.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-warm-100 flex gap-2">
                        <button
                          onClick={() => { setSelectedCountry(null); fetchCountryVisits(null, analyticsDays); }}
                          className="text-xs text-primary-500 hover:underline font-semibold">
                          View all visits →
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* ── Country visit log — appears when a country is clicked or "View all" ── */}
                {(countryVisits.length > 0 || countryVisitsLoading) && (
                  <div className="bg-white rounded-2xl border border-warm-100 p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-sm font-bold text-warm-700">
                          {selectedCountry ? `🗺️ Visits from ${selectedCountry}` : '🌐 All Country Visits'}
                        </h3>
                        {!countryVisitsLoading && (
                          <p className="text-xs text-warm-400 mt-0.5">{countryVisits.length} most recent visits · last {analyticsDays} days</p>
                        )}
                      </div>
                      <button onClick={() => fetchCountryVisits(selectedCountry, analyticsDays)}
                        className="text-xs px-3 py-1.5 rounded-xl border border-warm-200 text-warm-600 hover:border-primary-300 transition-colors">
                        ↻ Refresh
                      </button>
                    </div>

                    {countryVisitsLoading ? (
                      <div className="text-center py-8 text-warm-400 text-sm">Loading visit log…</div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="border-b border-warm-100">
                              <th className="text-left py-2 px-2 text-warm-400 font-semibold">Date &amp; Time</th>
                              <th className="text-left py-2 px-2 text-warm-400 font-semibold">Page</th>
                              <th className="text-left py-2 px-2 text-warm-400 font-semibold">Country</th>
                              <th className="text-left py-2 px-2 text-warm-400 font-semibold">City</th>
                              <th className="text-left py-2 px-2 text-warm-400 font-semibold">Visitor type</th>
                            </tr>
                          </thead>
                          <tbody>
                            {countryVisits.map((v, i) => {
                              const flag = v.country ? String.fromCodePoint(
                                ...[...v.country.toUpperCase()].slice(0,2).map(ch => 0x1F1E6 + ch.charCodeAt(0) - 65)
                              ) : '🌐';
                              const dt = new Date(v.created_at);
                              const dateStr = dt.toLocaleDateString('en-NG', { day:'numeric', month:'short', year:'numeric' });
                              const timeStr = dt.toLocaleTimeString('en-NG', { hour:'2-digit', minute:'2-digit', hour12:true });
                              return (
                                <tr key={i} className={`border-b border-warm-50 hover:bg-warm-50 transition-colors ${i % 2 === 0 ? '' : 'bg-gray-50/40'}`}>
                                  <td className="py-2 px-2 whitespace-nowrap">
                                    <p className="font-semibold text-warm-800">{dateStr}</p>
                                    <p className="text-warm-400">{timeStr}</p>
                                  </td>
                                  <td className="py-2 px-2">
                                    <span className="font-mono bg-warm-100 text-warm-700 px-1.5 py-0.5 rounded text-[10px]">{v.path || '/'}</span>
                                  </td>
                                  <td className="py-2 px-2 whitespace-nowrap">
                                    <span>{flag} {v.country || '—'}</span>
                                  </td>
                                  <td className="py-2 px-2 text-warm-500">{v.city || '—'}</td>
                                  <td className="py-2 px-2">
                                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                      v.user_type === 'authenticated' ? 'bg-primary-50 text-primary-600'
                                      : v.user_type === 'company' ? 'bg-blue-50 text-blue-600'
                                      : 'bg-warm-100 text-warm-500'
                                    }`}>{v.user_type || 'anonymous'}</span>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}

                {/* Avg per day */}
                <p className="text-xs text-warm-400 text-center">
                  Average {analytics.summary.avgPerDay} views/day over the last {analyticsDays} days.
                  Tracking started counting from your next deployment.
                </p>
              </>
            )}

            {!analytics && !analyticsLoading && (
              <div className="text-center py-16 text-warm-400">
                <p className="text-4xl mb-3">📊</p>
                <p className="font-medium">Click Refresh to load analytics</p>
              </div>
            )}
          </div>
        )}

        {tab === 'visitors' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-warm-900">Guest Visitors</h3>
                <p className="text-sm text-warm-400">People who signed cards without creating an account</p>
              </div>
              <div className="flex gap-2">
                <button onClick={sendNudge} disabled={nudging}
                  className="btn-secondary text-sm py-2 px-4 flex items-center gap-1.5"
                  title="Send conversion nudge emails to eligible unconverted visitors (max 4 per visitor, 7-day cooldown)">
                  {nudging ? <><Icon name="Loader" size={14} className="animate-spin" />Sending…</> : <><Icon name="Mail" size={14} />Send Nudge Emails</>}
                </button>
                <button type="button" onClick={fetchVisitors} className="btn-secondary inline-flex items-center gap-2 text-sm py-2 px-4"><Icon name="Refresh" size={14} />Refresh</button>
              </div>
            </div>

            {/* Visitor stats */}
            {visitorStats && (
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white rounded-2xl border border-purple-100 p-4 text-center">
                  <p className="text-2xl font-bold text-warm-900">{visitorStats.total || 0}</p>
                  <p className="text-xs text-warm-400 mt-1">Total visitors</p>
                </div>
                <div className="bg-white rounded-2xl border border-purple-100 p-4 text-center">
                  <p className="text-2xl font-bold text-green-700">{visitorStats.converted || 0}</p>
                  <p className="text-xs text-warm-400 mt-1">Converted to users</p>
                </div>
                <div className="bg-white rounded-2xl border border-purple-100 p-4 text-center">
                  <p className="text-2xl font-bold text-primary-600">
                    {visitorStats.total ? Math.round(((visitorStats.converted||0) / visitorStats.total) * 100) : 0}%
                  </p>
                  <p className="text-xs text-warm-400 mt-1">Conversion rate</p>
                </div>
              </div>
            )}

            {visitorsLoading ? <div className="h-32 rounded-2xl animate-pulse bg-purple-50" />
            : visitors.length === 0 ? (
              <EmptyState icon="👤" title="No guest visitors yet" sub="Guests who sign cards without creating accounts appear here. Run database/migration_all_fixes.sql if the visitors table doesn't exist." />
            ) : (
              <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead style={{ background:'#F8F6FF' }}>
                      <tr>{['Name / Email','Card signed','Occasion','Status','Nudge emails','Joined'].map(h=>(
                        <th key={h} className="text-left px-4 py-3 text-xs font-bold text-warm-500 uppercase tracking-wide">{h}</th>
                      ))}</tr>
                    </thead>
                    <tbody className="divide-y divide-purple-50">
                      {visitors.map(v => (
                        <tr key={v.id} className="hover:bg-purple-50/30">
                          <td className="px-4 py-3">
                            <p className="text-sm font-semibold text-warm-900">{v.full_name || v.author_name || '—'}</p>
                            <p className="text-xs text-warm-400">{v.email || v.author_email}</p>
                          </td>
                          <td className="px-4 py-3 text-xs text-warm-500">/{v.card_slug || '—'}</td>
                          <td className="px-4 py-3">
                            <Badge color="purple">{(v.occasion||'—').replace('_',' ')}</Badge>
                          </td>
                          <td className="px-4 py-3">
                            <Badge color={v.converted||v.converted_to_user ? 'green' : 'amber'}>
                              {v.converted||v.converted_to_user ? '✓ Converted' : '○ Guest'}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-sm text-warm-600">{v.nudge_count || v.emails_sent || 0} / 4</td>
                          <td className="px-4 py-3 text-xs text-warm-400">
                            {v.created_at ? format(new Date(v.created_at),'MMM d, yyyy') : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ─────────────── BLOG ─────────────── */}
        {tab === 'pals' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { l:'Total Groups',  v: palApplications.length },
                { l:'Approved',      v: palApplications.filter(p=>p.status==='approved').length },
                { l:'Pending',       v: palApplications.filter(p=>p.status==='pending').length },
                { l:'Open Tickets',  v: palTickets.filter(t=>t.status==='open').length },
              ].map(s=>(
                <div key={s.l} className="bg-white rounded-2xl border border-purple-100 p-4">
                  <p className="text-xs text-warm-400 mb-1">{s.l}</p>
                  <p className="text-2xl font-bold text-warm-900">{s.v}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
              <div className="px-5 py-4 border-b border-purple-50 font-semibold text-warm-900">Pals Group Applications</div>
              {palApplications.length === 0 ? (
                <EmptyState icon="👥" title="No Pals applications yet" sub="Groups that apply for a Thankeeu Pals account will appear here." />
              ) : (
                <div className="overflow-x-auto" style={{WebkitOverflowScrolling:'touch'}}>
                <table className="w-full text-sm" style={{minWidth:640}}>
                  <thead className="bg-purple-50 text-xs uppercase text-warm-500">
                    <tr>{['Group','Username','Email','Size','Status','Action'].map(h=>(
                      <th key={h} className="px-4 py-3 text-left">{h}</th>
                    ))}</tr>
                  </thead>
                  <tbody className="divide-y divide-purple-50">
                    {palApplications.map(p=>(
                      <tr key={p.id}>
                        <td className="px-4 py-3">
                          <p className="font-medium text-warm-900">{p.group_name}</p>
                          {p.description && <p className="text-xs text-warm-400 line-clamp-1 max-w-xs">{p.description}</p>}
                        </td>
                        <td className="px-4 py-3 text-warm-600">@{p.group_username}</td>
                        <td className="px-4 py-3 text-warm-600">{p.email}</td>
                        <td className="px-4 py-3 text-warm-600">{p.group_size}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold capitalize ${
                            p.status==='approved' ? 'bg-green-100 text-green-700' :
                            p.status==='pending'  ? 'bg-amber-100 text-amber-700' :
                            'bg-red-100 text-red-600'}`}>
                            {p.status}{p.status==='approved' && !p.is_verified ? ' (unverified)' : ''}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          {p.status === 'pending' && (
                            <div className="flex gap-2">
                              <button onClick={()=>approvePal(p.id, p.group_name)}
                                className="text-xs px-3 py-1.5 rounded-lg bg-green-50 text-green-700 hover:bg-green-100 font-semibold">
                                Approve
                              </button>
                              <button onClick={()=>setRejectModal(p)}
                                className="text-xs px-3 py-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 font-semibold">
                                Reject
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                </div>
              )}
            </div>

            {palTickets.length > 0 && (
              <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
                <div className="px-5 py-4 border-b border-purple-50 font-semibold text-warm-900">💬 Pals Support Tickets</div>
                <div className="divide-y divide-purple-50">
                  {palTickets.map(t => (
                    <PalTicketRow key={t.id} ticket={t} onReply={replyPalTicket} />
                  ))}
                </div>
              </div>
            )}

            {/* Reject modal */}
            {rejectModal && (
              <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
                <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl">
                  <h3 className="font-bold text-warm-900 mb-3">Reject "{rejectModal.group_name}"</h3>
                  <textarea rows={3} className="input w-full mb-4" placeholder="Reason (will be emailed to the applicant)..."
                    value={rejectReason} onChange={e=>setRejectReason(e.target.value)} />
                  <div className="flex gap-3">
                    <button onClick={()=>{setRejectModal(null); setRejectReason('');}} className="flex-1 py-2.5 rounded-xl border border-purple-200 text-sm font-semibold text-warm-600">Cancel</button>
                    <button onClick={rejectPal} className="flex-1 py-2.5 rounded-xl bg-red-500 text-white text-sm font-semibold">Reject & notify</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ─────────────── DISCOUNT CODES ─────────────── */}
        {tab === 'discounts' && (
          <DiscountCodesTab
            codes={discountCodes}
            loading={discountLoading}
            onCreate={createDiscountCode}
            onToggle={toggleDiscountCode}
            onDelete={deleteDiscountCode}
            redemptions={discountRedemptions}
            onLoadRedemptions={loadRedemptions}
          />
        )}

                {tab === 'vendors' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { l:'Total Vendors',   v: vendors.length },
                { l:'Approved',        v: vendors.filter(v=>v.status==='approved').length },
                { l:'Pending Review',  v: vendors.filter(v=>v.status==='pending').length },
                { l:'Gift Orders',     v: vendorOrders.length },
              ].map(s=>(
                <div key={s.l} className="bg-white rounded-2xl border border-purple-100 p-4">
                  <p className="text-xs text-warm-400 mb-1">{s.l}</p>
                  <p className="text-2xl font-bold text-warm-900">{s.v}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
              <div className="px-5 py-4 border-b border-purple-50 font-semibold text-warm-900">Vendors</div>
              <div className="overflow-x-auto" style={{WebkitOverflowScrolling:'touch'}}>
              <table className="w-full text-sm" style={{minWidth:560}}>
                <thead className="bg-purple-50 text-xs uppercase text-warm-500">
                  <tr>
                    {['Store','Category','Status','Verified','Action'].map(h=>(
                      <th key={h} className="px-4 py-3 text-left">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-purple-50">
                  {vendors.map(v=>(
                    <tr key={v.id}>
                      <td className="px-4 py-3">
                        <p className="font-medium text-warm-900">{v.business_name}</p>
                        <p className="text-xs text-warm-400">{v.email}</p>
                      </td>
                      <td className="px-4 py-3 capitalize text-warm-600">{v.category}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold capitalize ${
                          v.status==='approved' ? 'bg-green-100 text-green-700' :
                          v.status==='pending'  ? 'bg-amber-100 text-amber-700' :
                          'bg-red-100 text-red-600'}`}>
                          {v.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {v.is_verified
                          ? <span className="text-xs font-semibold text-green-600 flex items-center gap-1">✅ Verified</span>
                          : <span className="text-xs font-semibold text-amber-600 flex items-center gap-1">⏳ Unverified</span>
                        }
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1.5">
                          {/* Verify & Activate — shown if not yet verified OR not approved */}
                          {(!v.is_verified || v.status !== 'approved') && (
                            <button onClick={async () => {
                              const base = import.meta.env.VITE_API_URL||'/api';
                              const hdr  = {'Content-Type':'application/json', Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`};
                              try {
                                const r = await fetch(`${base}/vendor/admin/vendors/${v.id}/verify-activate`, { method:'POST', headers: hdr });
                                const d = await r.json();
                                if (!r.ok) throw new Error(d.error);
                                toast.success(d.message);
                                fetchVendors();
                              } catch(e) { toast.error(e.message); }
                            }} className="text-xs px-3 py-1.5 rounded-lg bg-green-50 text-green-700 hover:bg-green-100 font-semibold border border-green-200">
                              ✅ Verify &amp; Activate
                            </button>
                          )}

                          {/* Resend verification — only if not yet verified */}
                          {!v.is_verified && (
                            <button onClick={async () => {
                              const base = import.meta.env.VITE_API_URL||'/api';
                              const hdr  = {'Content-Type':'application/json', Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`};
                              try {
                                const r = await fetch(`${base}/vendor/admin/vendors/${v.id}/resend-verify`, { method:'POST', headers: hdr });
                                const d = await r.json();
                                if (!r.ok) throw new Error(d.error);
                                toast.success(d.message);
                              } catch(e) { toast.error(e.message); }
                            }} className="text-xs px-3 py-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 font-semibold border border-amber-200">
                              📧 Resend link
                            </button>
                          )}

                          {/* Suspend if currently approved */}
                          {v.status === 'approved' && (
                            <button onClick={async () => {
                              const base = import.meta.env.VITE_API_URL||'/api';
                              const hdr  = {'Content-Type':'application/json', Authorization:`Bearer ${localStorage.getItem('thankeeu_token')}`};
                              try {
                                await fetch(`${base}/vendor/admin/vendors/${v.id}/status`, { method:'PUT', headers: hdr, body: JSON.stringify({status:'suspended'}) });
                                fetchVendors(); toast.success('Vendor suspended');
                              } catch(e) { toast.error(e.message); }
                            }} className="text-xs px-3 py-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 font-semibold border border-red-200">
                              Suspend
                            </button>
                          )}

                          <a href={`/c/${v.slug}`} target="_blank" rel="noopener noreferrer"
                            className="text-xs px-3 py-1.5 rounded-lg bg-purple-50 text-primary-600 hover:bg-purple-100 font-semibold border border-purple-200">
                            View store
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              </div>
            </div>

            {vendorOrders.length > 0 && (
              <div className="bg-white rounded-2xl border border-purple-100 overflow-hidden">
                <div className="px-5 py-4 border-b border-purple-50 font-semibold text-warm-900">🎂 Gift Orders via Thankeeu</div>
                <div className="overflow-x-auto" style={{WebkitOverflowScrolling:'touch'}}>
                <table className="w-full text-sm" style={{minWidth:640}}>
                  <thead className="bg-purple-50 text-xs uppercase text-warm-500">
                    <tr>
                      {['Order','Vendor','Customer','Total','Fee','Status'].map(h=>(
                        <th key={h} className="px-4 py-3 text-left">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-purple-50">
                    {vendorOrders.slice(0,50).map(o=>(
                      <tr key={o.id}>
                        <td className="px-4 py-3 font-mono text-xs">#{o.id.slice(0,8).toUpperCase()}</td>
                        <td className="px-4 py-3 text-warm-700">{o.vendor_name||'—'}</td>
                        <td className="px-4 py-3">
                          <p className="text-warm-900">{o.customer_name}</p>
                          {o.card_slug && <p className="text-xs text-primary-500">Card: {o.card_slug}</p>}
                        </td>
                        <td className="px-4 py-3 font-semibold">₦{(o.total_amount||0).toLocaleString()}</td>
                        <td className="px-4 py-3 text-pink-600 font-semibold">₦{(o.platform_fee||5000).toLocaleString()}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold capitalize ${
                            o.status==='delivered' ? 'bg-green-100 text-green-700' :
                            o.status==='shipped'   ? 'bg-blue-100 text-blue-700' :
                            'bg-amber-100 text-amber-700'}`}>
                            {o.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                </div>
              </div>
            )}
          </div>
        )}

                {tab === 'blog' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex flex-wrap gap-2">
                {['all','published','draft'].map(s=>(
                  <Badge key={s} color={s==='published'?'green':s==='draft'?'amber':'gray'}>
                    {s} ({s==='all' ? blogPosts.length : blogPosts.filter(p=>p.status===s).length})
                  </Badge>
                ))}
              </div>
              <button onClick={()=>{ setBlogEditing(null); setBlogForm({ title:'',excerpt:'',content:'',category:'General',tags:'',status:'draft',is_featured:false,cover_image:'',author_name:'Thankeeu Team' }); }}
                className="btn-primary text-sm py-2 px-4">+ New post</button>
            </div>

            {/* Blog editor */}
            {(blogEditing !== null || blogForm.title !== undefined) && (
              <div className="bg-white rounded-2xl border border-purple-100 p-6 space-y-4">
                <h3 className="font-bold text-warm-900">{blogEditing ? 'Edit post' : 'New post'}</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="text-xs font-medium text-warm-500 block mb-1">Title *</label>
                    <input className="input text-sm" value={blogForm.title} onChange={e=>setBlogForm(p=>({...p,title:e.target.value}))} /></div>
                  <div><label className="text-xs font-medium text-warm-500 block mb-1">Category</label>
                    <input className="input text-sm" value={blogForm.category} onChange={e=>setBlogForm(p=>({...p,category:e.target.value}))} /></div>
                </div>
                <div><label className="text-xs font-medium text-warm-500 block mb-1">Excerpt</label>
                  <textarea className="input text-sm resize-none h-16" value={blogForm.excerpt} onChange={e=>setBlogForm(p=>({...p,excerpt:e.target.value}))} /></div>
                <div><label className="text-xs font-medium text-warm-500 block mb-1">Content (Markdown)</label>
                  <textarea className="input text-sm resize-none h-40 font-mono" value={blogForm.content} onChange={e=>setBlogForm(p=>({...p,content:e.target.value}))} /></div>
                <div className="flex items-center gap-3 flex-wrap">
                  <select className="input text-sm w-auto" value={blogForm.status} onChange={e=>setBlogForm(p=>({...p,status:e.target.value}))}>
                    <option value="draft">Draft</option><option value="published">Published</option><option value="archived">Archived</option>
                  </select>
                  <label className="flex items-center gap-2 text-sm text-warm-700 cursor-pointer">
                    <input type="checkbox" checked={blogForm.is_featured} onChange={e=>setBlogForm(p=>({...p,is_featured:e.target.checked}))} />
                    Featured
                  </label>
                  <button onClick={saveBlogPost} disabled={blogSaving} className="btn-primary text-sm py-2 px-5">{blogSaving?'Saving…':'Save post'}</button>
                  <button onClick={()=>setBlogEditing(null)} className="btn-secondary text-sm py-2 px-4">Cancel</button>
                </div>
              </div>
            )}

            {blogLoading ? [...Array(3)].map((_,i)=><div key={i} className="h-20 rounded-2xl animate-pulse bg-purple-50"/>)
            : blogPosts.map(p => (
              <div key={p.id} className="bg-white rounded-2xl border border-purple-100 flex items-center gap-4 px-5 py-4 hover:shadow-sm transition-shadow">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="font-semibold text-warm-900 text-sm truncate">{p.title}</p>
                    {p.is_featured && <Badge color="amber">⭐ Featured</Badge>}
                    <Badge color={p.status==='published'?'green':p.status==='draft'?'amber':'gray'}>{p.status}</Badge>
                  </div>
                  <p className="text-xs text-warm-400">{p.category} · {p.created_at ? format(new Date(p.created_at),'MMM d, yyyy') : '—'}</p>
                </div>
                <button onClick={()=>{ setBlogEditing(p); setBlogForm({...p, tags: Array.isArray(p.tags)?p.tags.join(', '):p.tags||''}); }}
                  className="text-xs text-primary-500 hover:bg-primary-50 px-3 py-1.5 rounded-lg">Edit</button>
              </div>
            ))}
          </div>
        )}

        {/* ── SETTINGS TAB ── */}
        {tab === 'coverdesigns' && <CoverDesignTab />}
        {tab === 'settings' && <SettingsTab />}

        </div>
      </main>
    </div>
  );
};

export default Admin;
