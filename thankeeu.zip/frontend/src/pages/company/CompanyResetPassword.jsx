import { useSEO } from '../../hooks/useSEO';
import { useState } from 'react';
import ThankeeuLogo from '../../components/ThankeeuLogo';
import Navbar from '../../components/Navbar';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { companyAPI } from '../../utils/api';
import toast from 'react-hot-toast';

const CompanyResetPassword = () => {
  useSEO({ title: 'Set New Company Password — Thankeeu for Teams', description: 'Set a new password for your company account.', noIndex: true });

  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const navigate = useNavigate();
  const [form, setForm] = useState({ password: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(false);
  const [done, setDone] = useState(false);

  if (!token) return (
    <div className="min-h-screen"><Navbar /><div className="flex items-center justify-center p-4 py-12 md:py-20">
      <div className="text-center">
        <div className="text-5xl mb-4">🔗</div>
        <h2 className="font-display text-2xl font-semibold text-warm-900 mb-2">Invalid reset link</h2>
        <p className="text-warm-500 mb-6 text-sm">This link is invalid or has expired.</p>
        <Link to="/company/forgot-password" className="btn-primary">Request a new link</Link>
      </div>
    </div></div>
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password.length < 8) return toast.error('Password must be at least 8 characters');
    if (form.password !== form.confirm) return toast.error('Passwords do not match');
    setLoading(true);
    try {
      await companyAPI.resetPassword({ token, password: form.password });
      setDone(true);
      setTimeout(() => navigate('/company/login'), 3000);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Reset failed — link may have expired');
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen"><Navbar /><div className="flex items-center justify-center p-4 py-12 md:py-20">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-primary-50 text-primary-600 text-xs font-medium px-3 py-1.5 rounded-full mb-3">
            🏢 For Teams
          </div>
          <h1 className="font-display text-3xl font-semibold text-warm-900 mb-2">Set new password</h1>
          <p className="text-warm-500 text-sm">Choose a strong password for your company account</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-8 border border-purple-100">
          {done ? (
            <div className="text-center py-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">✅</div>
              <h3 className="font-display text-xl font-semibold text-warm-900 mb-2">Password reset!</h3>
              <p className="text-warm-500 text-sm mb-2">Your company password has been updated.</p>
              <p className="text-xs text-warm-700">Redirecting to login...</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-warm-700 mb-1.5">New password</label>
                <div className="relative">
                  <input type={show ? 'text' : 'password'} className="input pr-10"
                    placeholder="At least 8 characters" required minLength={8}
                    value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} />
                  <button type="button" onClick={() => setShow(!show)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-warm-700 text-xs">
                    {show ? 'Hide' : 'Show'}
                  </button>
                </div>
                {form.password && (
                  <div className="mt-2 flex gap-1">
                    {[...Array(4)].map((_, i) => (
                      <div key={i} className={`h-1 flex-1 rounded-full transition-colors ${
                        form.password.length > i * 2 + 3 ? 'bg-primary-400' : 'bg-gray-200'
                      }`} />
                    ))}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-warm-700 mb-1.5">Confirm new password</label>
                <input type="password" className="input" placeholder="Repeat new password" required
                  value={form.confirm} onChange={e => setForm(p => ({ ...p, confirm: e.target.value }))} />
                {form.confirm && form.password !== form.confirm && (
                  <p className="text-xs text-red-500 mt-1">Passwords do not match</p>
                )}
              </div>
              <button type="submit" disabled={loading || form.password !== form.confirm} className="btn-primary w-full py-3.5 disabled:opacity-50">
                {loading
                  ? <span className="flex items-center justify-center gap-2">
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Resetting...
                    </span>
                  : 'Reset company password'}
              </button>
              <p className="text-center text-sm text-warm-500">
                <Link to="/company/login" className="text-primary-400 font-medium hover:text-primary-600">← Back to login</Link>
              </p>
            </form>
          )}
        </div>
      </div>
      </div>
    </div>
  );
};

export default CompanyResetPassword;
