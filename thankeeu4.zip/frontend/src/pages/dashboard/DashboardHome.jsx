import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { dashboardAPI, cardsAPI, paymentsAPI, authAPI } from '../../utils/api';
import DashboardLayout from '../../components/DashboardLayout';
import toast from 'react-hot-toast';
import { formatNGN } from '../../utils/currency';

const occasionEmoji = { birthday:'🎂',valentine:'💝',leaving:'💼',anniversary:'💍',wedding:'💒',baby_shower:'👶',retirement:'🏖️',congratulations:'🎉',graduation:'🎓',promotion:'🌟',christmas:'🎄',get_well:'🌷',new_year:'✨',other:'💌' };

export default function DashboardHome() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const completingPayment = useRef(false);


  // Handle redirect from Flutterwave after card-creation fee payment
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const feePaid = params.get('fee_paid');
    if (feePaid) {
      // Bug 8 fix: verify AND navigate to the activated card
      window.history.replaceState({}, '', '/dashboard'); // clean URL immediately
      const base = import.meta.env.VITE_API_URL || '/api';
      const tok  = localStorage.getItem('thankeeu_token') || localStorage.getItem('thankeeu_member_token');
      fetch(`${base}/payments/verify/purchase/${encodeURIComponent(feePaid)}`, {
        headers: { Authorization: `Bearer ${tok}` }
      }).then(r => r.json()).then(data => {
        if ((data.status === 'success' || data.verified) && data.card_slug) {
          toast.success('✅ Payment confirmed! Taking you to your card...');
          // Navigate to the activated card after a brief delay
          setTimeout(() => window.location.replace(`/card/${data.card_slug}`), 1200);
        } else if (data.status === 'success' || data.verified) {
          toast.success('✅ Card payment confirmed! Your card is now active.');
        }
      }).catch(() => toast.error('Could not verify payment. Please check My Cards.'));
    }
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('payment') === 'success') {
      if (completingPayment.current) return;
      completingPayment.current = true;
      const ref = params.get('reference') || params.get('trxref');
      (async () => {
        try {
          let verification;
          for (let i = 0; i < 4; i++) {
            try { verification = await paymentsAPI.verifyCardFee(ref); break; }
            catch (e) { if (i === 3) throw e; await new Promise(r => setTimeout(r, 750*(i+1))); }
          }
          const pending = JSON.parse(localStorage.getItem('thankeeu_pending_card') || 'null');
          let slug = verification?.data?.card_slug || pending?.slug;
          if (!slug) { const r = await cardsAPI.create(pending.cardData); slug = r.data.slug; }
          // Bug 7 fix: verifyPayment activates card on backend — no separate activate() needed
          // Only call activate as fallback if card_slug wasn't returned (very old flow)
          if (!verification?.data?.card_slug) {
            await cardsAPI.activate(slug, { inviteEmails: pending?.inviteEmails || [] }).catch(() => {});
          }
          localStorage.removeItem('thankeeu_pending_card');
          toast.success('🎉 Card is live!');
          navigate(`/card/${slug}`, { replace: true });
        } catch (err) {
          toast.error(err.response?.data?.error || 'Could not finish card. Reload to retry.');
          completingPayment.current = false;
          fetchData();
        }
      })();
    } else { fetchData(); }
  }, []);

  const fetchData = async () => {
    try { const r = await dashboardAPI.get(); setData(r.data); }
    catch { toast.error('Failed to load'); }
    finally { setLoading(false); }
  };

  const stats = data?.stats || {};
  const cards = data?.recent_cards || [];
  const notifications = data?.notifications || [];
  const [dismissed, setDismissed] = useState([]);
  const [resending, setResending] = useState(false);
  const [resentOk, setResentOk] = useState(false);

  const resendVerification = async () => {
    setResending(true);
    try {
      await authAPI.resendVerification();
      setResentOk(true);
      toast.success('Verification email sent! Check your inbox 📬');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to send. Try again.');
    } finally { setResending(false); }
  };

  const getNotifLink = (n) => {
    const type = n.type || '';
    if (type === 'card_opened' || type === 'card_scheduled' || type === 'card_sent') {
      return n.meta?.card_slug ? `/card/${n.meta.card_slug}` : '/dashboard/cards';
    }
    if (type === 'card_received') return '/dashboard/received';
    if (type === 'reminder_due' || type === 'reminder_set') return '/dashboard/reminders';
    if (type === 'pending_sign') return '/dashboard/pending';
    return '/dashboard';
  };

  const dismissNotif = async (id, e) => {
    e.preventDefault(); e.stopPropagation();
    setDismissed(prev => [...prev, id]);
    try { await dashboardAPI.markNotificationsRead(); } catch {}
  };

  const visibleNotifs = notifications.filter(n => !dismissed.includes(n.id));

  return (
    <DashboardLayout title={`Hey ${user?.full_name?.split(' ')[0] || 'there'} 👋`} subtitle="Here's what's happening with your cards">

      {/* ── Email verification banner ── */}
      {user && user.is_verified === false && (
        <div className="mb-5 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center gap-3"
          style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.3)' }}>
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <span className="text-xl flex-shrink-0">📬</span>
            <div>
              <p className="text-sm font-semibold" style={{ color: '#1A1730' }}>Please verify your email address</p>
              <p className="text-xs mt-0.5" style={{ color: '#7A7898' }}>
                Check your inbox for a verification link. You can still use Thankeeu normally — verification just confirms your account.
              </p>
            </div>
          </div>
          <button
            onClick={resendVerification}
            disabled={resending || resentOk}
            className="flex-shrink-0 text-xs font-semibold px-4 py-2 rounded-xl transition-all disabled:opacity-60"
            style={{ background: resentOk ? 'rgba(16,185,129,0.12)' : 'rgba(245,158,11,0.15)', color: resentOk ? '#059669' : '#d97706', border: `1px solid ${resentOk ? 'rgba(16,185,129,0.3)' : 'rgba(245,158,11,0.3)'}` }}>
            {resending ? '⏳ Sending...' : resentOk ? '✓ Email sent!' : '📧 Resend verification email'}
          </button>
        </div>
      )}

      {/* Notifications */}
      {visibleNotifs.length > 0 && (
        <div className="space-y-2 mb-5">
          {visibleNotifs.slice(0,5).map(n => (
            <Link key={n.id} to={getNotifLink(n)}
              className="flex items-start gap-3 p-3 rounded-2xl group relative no-underline block transition-all hover:opacity-90"
              style={{ background:'rgba(124,110,255,0.06)', border:'1px solid rgba(124,110,255,0.15)' }}>
              <span className="text-lg flex-shrink-0">🔔</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold" style={{ color:'#1A1730' }}>{n.title}</p>
                <p className="text-xs mt-0.5" style={{ color:'#7A7898' }}>{n.body}</p>
              </div>
              <button
                onClick={(e) => dismissNotif(n.id, e)}
                className="flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ background:'rgba(0,0,0,0.12)', color:'#7A7898' }}>
                ✕
              </button>
            </Link>
          ))}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {loading
          ? [...Array(4)].map((_,i) => <div key={i} className="rounded-2xl h-24 animate-pulse" style={{ background:'#EDE9FF' }} />)
          : [
              { icon:'💌', label:'Active cards', value: stats.active_cards||0 },
              { icon:'📋', label:'Total cards', value: stats.total_cards||0 },
              { icon:'🚀', label:'Sent', value: stats.sent_cards||0 },
              { icon:'🎁', label:'Gifts collected', value: formatNGN(stats.total_collected||0), hi:true },
            ].map(s => (
              <div key={s.label} className="dash-card p-4" style={s.hi ? { background:'rgba(124,110,255,0.06)', borderColor:'rgba(124,110,255,0.25)' } : undefined}>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs font-medium mb-1" style={{ color:'#7A7898' }}>{s.label}</p>
                    <p className="font-bold text-xl" style={{ fontFamily:'Space Grotesk,sans-serif', color: s.hi?'#5B4BDF':'#1A1730' }}>{s.value}</p>
                  </div>
                  <span className="text-2xl">{s.icon}</span>
                </div>
              </div>
            ))
        }
      </div>

      {/* Recent cards */}
      <div className="flex items-center justify-between mb-3">
        <h2 style={{ fontFamily:'Space Grotesk,sans-serif', fontWeight:600, fontSize:'1rem', color:'#1A1730' }}>Recent cards</h2>
        <Link to="/dashboard/cards" className="text-xs font-medium" style={{ color:'#7C6EFF' }}>View all →</Link>
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{[...Array(3)].map((_,i) => <div key={i} className="rounded-2xl h-40 animate-pulse" style={{ background:'#EDE9FF' }} />)}</div>
      ) : cards.length === 0 ? (
        <div className="dash-empty py-14">
          <div className="text-5xl mb-3">💌</div>
          <p className="font-semibold mb-4" style={{ color:'#1A1730' }}>No cards yet</p>
          <Link to="/card/new" className="dash-btn-primary text-sm px-6 py-2.5 inline-flex items-center gap-1.5">✨ Create your first card</Link>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {cards.map(card => (
            <div key={card.id} className="dash-card dash-card-hover overflow-hidden">
              <div className="p-4">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-2xl">{occasionEmoji[card.occasion]||'💌'}</span>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full"
                    style={{ background: card.status==='active'?'#dcfce7':card.status==='sent'?'#dbeafe':'#f3e8ff', color: card.status==='active'?'#166534':card.status==='sent'?'#1e40af':'#6b21a8' }}>
                    {card.status}
                  </span>
                </div>
                <p className="text-sm font-semibold line-clamp-1" style={{ color:'#1A1730' }}>{card.title}</p>
                <p className="text-xs mt-0.5" style={{ color:'#7A7898' }}>For {card.recipient_name}</p>
                <div className="flex gap-3 mt-2 text-xs" style={{ color:'#9490C8' }}>
                  <span>✍️ {card.signed_count||0}</span>
                  {(card.total_collected||0)>0 && <span className="font-semibold" style={{ color:'#059669' }}>🎁 {formatNGN(card.total_collected)}</span>}
                </div>
              </div>
              <div className="flex border-t" style={{ borderColor:'#EDE9FF' }}>
                <Link to={`/card/${card.slug}`} className="flex-1 py-2.5 text-center text-xs font-semibold hover:bg-purple-50" style={{ color:'#5B4BDF' }}>👁️ View</Link>
                {card.status==='active' && (
                  <button className="flex-1 py-2.5 text-xs font-semibold hover:bg-purple-50 border-l" style={{ color:'#5B4BDF', borderColor:'#EDE9FF' }}
                    onClick={() => { navigator.clipboard.writeText(`${location.origin}/sign/${card.slug}`); toast.success('Copied!'); }}>
                    📲 Copy link
                  </button>
                )}
              </div>
            </div>
          ))}
          <Link to="/card/new" className="flex flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed p-6 min-h-36 transition-all hover:border-primary-400 hover:bg-purple-50" style={{ borderColor:'#DDD8FF' }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background:'#EDE9FF' }}>✨</div>
            <p className="text-sm font-semibold" style={{ color:'#7A7898' }}>Create new card</p>
          </Link>
        </div>
      )}
    </DashboardLayout>
  );
}
